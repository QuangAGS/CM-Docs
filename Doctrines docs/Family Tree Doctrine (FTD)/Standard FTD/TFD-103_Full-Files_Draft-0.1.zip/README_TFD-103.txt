TFD-103 — Full files
Dự thảo 0.1 | 20-10-2026

Files:
- TFD-103_Quy-tac-su-kien-nien-dai-va-nguon-chung-cu.docx: editable Word document
- TFD-103_Quy-tac-su-kien-nien-dai-va-nguon-chung-cu.md: Markdown source
- TFD-103_PostgreSQL-tham-khao.sql: PostgreSQL reference schema
- README_TFD-103.txt: this file

Status:
Draft 0.1 for review. This is not an official standard or production-ready database migration.
The SQL is a starter schema and must be aligned with TFD-101/TFD-102, then tested before deployment.
