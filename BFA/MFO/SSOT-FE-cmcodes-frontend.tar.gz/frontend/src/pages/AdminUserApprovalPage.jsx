/**
 * =============================================================================
 * PATH       : frontend/src/pages/AdminUserApprovalPage.jsx
 * DATETIME   : 2026-11-23T16:30:00+07:00
 * VERSION    : 25.8.0-ISO29148-RPOP-NO-TOAST
 * DESCRIPTION:
 * - [AMEND-RP-OP-2026-02 V1.5.0 Lát 4] Trang danh sách & điều phối xét duyệt hồ sơ Admin:
 *   + Gắn 4 nhãn phân loại hồ sơ: [NHẬN NGƯỜI TRÊN CÂY - EM], [KHAI BÁO MỚI - 21 TRƯỜNG],
 *     [LẬP DÒNG HỌ MỚI - CLAN SETUP], [GIA NHẬP HỌ THỨ HAI - C1].
 *   + Điều phối duyệt / trả sửa hồ sơ Multi-Home (C1 / C1-S) gọi qua
 *     membershipApi (/api/membership/cases/:caseId/*) sử dụng roleInTenant.
 *   + Giữ nguyên luồng C2 / C2-S (/auth/process-approval, /auth/return-for-revision)
 *     và nhánh OP (?process=OP -> OpApprovalPanel).
 * =============================================================================
 * CHANGELOGS:
 * - 2026-08-18T21:05:00+07:00 (v25.1.3-FE-OP-B2): Data bridging + OpApprovalPanel.
 * - 2026-11-13T11:30:00+07:00 (v25.2.0-MULTIHOME-AMEND02-V15-LAT4):
 *   + Bổ sung badge 4 loại hồ sơ và định tuyến duyệt C1 / C1-S sang /membership/cases/:caseId/*.
 * =============================================================================
 * QX: Tuân thủ chặt chẽ Q1–Q4.
 */

import { useState, useEffect, useCallback } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { 
  Search, 
  SlidersHorizontal, 
  ChevronLeft, 
  ChevronRight, 
  UserCheck, 
  UserX, 
  ShieldAlert, 
  RefreshCw 
} from 'lucide-react';
import UserApprovalForm from '../features/admin/components/UserApprovalForm.jsx';
import AdminClanLookupDrawer from '../features/admin/components/AdminClanLookupDrawer.jsx';
import apiClient from '../lib/apiClient.js';
import { membershipApi } from '../features/membership/api/membershipApi.js';
import { useAuth } from '../context/AuthContext.jsx';
//FE-OP-B2
import OpApprovalPanel from '../features/admin/components/OpApprovalPanel.jsx';
import TenantHeader from '../components/shell/TenantHeader.jsx';
import { resolveTenant } from '../lib/resolveTenant.js';
import AppFooterNav from '../components/shell/AppFooterNav.jsx';
import { resolveFooterNav } from '../lib/resolveFooterNav.js';
import AudioHelpButton from '../features/elder-doctrine/components/AudioHelpButton.jsx';
import { ADMIN_APPROVAL_RP_HELP } from '../features/admin/constants/adminMessages.js';
import PersistentMessageBanner from '../components/common/PersistentMessageBanner.jsx';
import BlockingLoadingOverlay from '../components/common/BlockingLoadingOverlay.jsx';
import { extractApiErrorInfo } from '../shared/hooks/useTurnstileFailClosed.js';

const STATUS_BADGES = {
  CHO_DUYET: 'bg-amber-50 text-amber-700 border-amber-200',
  NEEDS_REVISION: 'bg-sky-50 text-sky-800 border-sky-300',
  DA_DUYET: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  TU_CHOI: 'bg-rose-50 text-rose-700 border-rose-200',
  BI_KHOA: 'bg-slate-100 text-slate-700 border-slate-300 font-black',
};

const STATUS_LABELS = {
  CHO_DUYET: 'Chờ duyệt',
  NEEDS_REVISION: 'Yêu cầu bổ sung',
  DA_DUYET: 'Đang hoạt động',
  TU_CHOI: 'Bị từ chối',
  BI_KHOA: 'Đang bị khóa',
};

// PR-OP-4 + UAT-Bug 10 helper phân biệt hồ sơ đã trả bổ sung (NEEDS_REVISION) vs Chờ duyệt mới
const getStatusLabel = (item) => {
  if (item.status === 'TU_CHOI' && item.isFinalRejection) {
    return 'Từ chối lần cuối';
  }
  if (
    item.caseStatus === 'NEEDS_REVISION' &&
    item.status !== 'DA_DUYET' &&
    item.status !== 'TU_CHOI'
  ) {
    return STATUS_LABELS.NEEDS_REVISION;
  }
  return STATUS_LABELS[item.status] || item.status;
};

const getStatusBadgeClass = (item) => {
  if (item.status === 'TU_CHOI' && item.isFinalRejection) {
    return 'bg-rose-100 text-rose-900 border-rose-400';
  }
  if (
    item.caseStatus === 'NEEDS_REVISION' &&
    item.status !== 'DA_DUYET' &&
    item.status !== 'TU_CHOI'
  ) {
    return STATUS_BADGES.NEEDS_REVISION;
  }
  return STATUS_BADGES[item.status] || 'bg-slate-50';
};

const CASE_CATEGORY_META = {
  CLAIM_EM: {
    label: '[NHẬN NGƯỜI TRÊN CÂY - EM]',
    badgeClass: 'bg-emerald-50 text-emerald-800 border-emerald-200',
  },
  NEW_MEMBER_21_FIELDS: {
    label: '[KHAI BÁO MỚI - 21 TRƯỜNG]',
    badgeClass: 'bg-blue-50 text-blue-800 border-blue-200',
  },
  CLAN_SETUP_C2S: {
    label: '[LẬP DÒNG HỌ MỚI - CLAN SETUP (C2-S)]',
    badgeClass: 'bg-purple-50 text-purple-800 border-purple-200',
  },
  CLAN_SETUP_C1S: {
    label: '[LẬP DÒNG HỌ MỚI - CLAN SETUP (C1-S)]',
    badgeClass: 'bg-fuchsia-50 text-fuchsia-800 border-fuchsia-200',
  },
  MULTIHOME_C1: {
    label: '[GIA NHẬP HỌ THỨ HAI - C1]',
    badgeClass: 'bg-indigo-50 text-indigo-800 border-indigo-200',
  },
};

const getCaseCategoryMeta = (item) => {
  const cat = item?.claimCategory;
  if (cat && CASE_CATEGORY_META[cat]) {
    return CASE_CATEGORY_META[cat];
  }
  if (item?.caseType === 'CLAN_SETUP') {
    return item?.isMultiHomeCase
      ? CASE_CATEGORY_META.CLAN_SETUP_C1S
      : CASE_CATEGORY_META.CLAN_SETUP_C2S;
  }
  if (item?.isMultiHomeCase) {
    return CASE_CATEGORY_META.MULTIHOME_C1;
  }
  const snap = item?.temp_snapshot || {};
  const meta = item?.caseMetadata || {};
  if (snap.claimed_member_id || meta.claimed_member_id || meta.registration_profile?.claimed_member_id) {
    return CASE_CATEGORY_META.CLAIM_EM;
  }
  return CASE_CATEGORY_META.NEW_MEMBER_21_FIELDS;
};

const AdminUserApprovalPage = () => {
  const { user: currentUser, logout } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const sessionTenant = resolveTenant(currentUser);
  const footerNav = resolveFooterNav(currentUser, {
    pageKey: 'admin-approval',
    backTo: '/admin',
    showBack: true,
  });
  const handleLogout = () => {
    logout();
    navigate('/auth', { replace: true });
  };

  // State quản lý danh sách & phân trang nhận từ Backend
  const [usersList, setUsersList] = useState([]);
  const [pagination, setPagination] = useState({ total_records: 0, current_page: 1, total_pages: 1 });
  
  // State quản lý Trạng thái nghiệp vụ
  const [selectedUser, setSelectedUser] = useState(null);
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [showFilters, setShowFilters] = useState(false); // Toggle bộ lọc trên mobile
  const [bannerState, setBannerState] = useState(null);
  const [isClanLookupOpen, setIsClanLookupOpen] = useState(false);
  const [clanLookupInitialQuery, setClanLookupInitialQuery] = useState('');
  const [clanLookupMode, setClanLookupMode] = useState('MEMBERS');

  // State lưu trữ các "Mối quan tâm" (Bộ lọc động)
  const [filters, setFilters] = useState({
    status: 'CHO_DUYET', // Mặc định hiển thị hồ sơ đăng ký mới
    role: '',
    caseType: '',
    searchKeyword: '',
    page: 1,
    limit: 10
  });

  // Hàm gọi API truy vấn động
  const fetchReviewableUsers = useCallback(async (currentFilters) => {
    setLoading(true);
    try {
      // Chuyển đổi các trường trống thành undefined để tối ưu hóa query string params
      const params = {};
      Object.keys(currentFilters).forEach(key => {
        if (key === 'caseType') return;
        if (currentFilters[key] !== '') params[key] = currentFilters[key];
      });

      const response = await apiClient.post('/auth/query-reviewable-users', params);
      
      const rawData = response.data?.data || response.data || [];
      const rawUsersArray = Array.isArray(rawData) ? rawData : (rawData.data || []);
      const serverPagination = rawData.pagination || { total_records: rawUsersArray.length, current_page: 1, total_pages: 1 };

      /**
       * 🚨 KHỐI MÃ LỆNH ÁNH XẠ VẾT CẠN DỮ LIỆU ĐỐI CHIẾU <2026-06-20T12:18:00+07:00>
       * LÝ DO: Giao diện UserApprovalForm cần Năm sinh, Tên Cha/Mẹ, Mô tả dòng họ để Admin đối chiếu thông tin chính xác.
       * CHỨC NĂNG: Khai thác triệt để các trường lồng sâu trong temp_snapshot và tenant để đẩy lên các thuộc tính phẳng.
       */
      const normalizedUsers = rawUsersArray
        .map(item => {
          if (!item) return item;

          const actualUser = item.userData || item;
          const snapshot = actualUser.temp_snapshot || item.temp_snapshot || {};
          const actualTenant = actualUser.tenant || item.tenant || null;
          const actualMember = actualUser.member_profile || item.memberData || null;

          // Trích xuất thông tin đối chiếu thô từ hồ sơ đăng ký của thành viên
          const registrationFullName = snapshot.full_name || item.temp_full_name || actualUser.name || 'Thành viên chưa đặt tên';
          const registrationBirthYear = snapshot.birth_year || actualUser.birth_year || 'Chưa cập nhật';
          const registrationFatherName = snapshot.father_name || actualUser.father_name || 'Chưa rõ';
          const registrationMotherName = snapshot.mother_name || actualUser.mother_name || 'Chưa rõ';
          const registrationRelationship = snapshot.relationship_to_clan || actualUser.relationship_to_clan || 'Thành viên đăng ký mới';

          return {
            // 🏛️ LỚP 1: Các trường phẳng bề nổi phục vụ hiển thị tức thì trên Thẻ Card và Form
            id: actualUser.id || item.id,
            caseId: item.caseId || actualUser.caseId || null,
            isMultiHomeCase:
              item.isMultiHomeCase === true ||
              actualUser.isMultiHomeCase === true,
            claimCategory:
              item.claimCategory || actualUser.claimCategory || null,
            caseType: item.caseType || actualUser.caseType || null,
            caseStatus: item.caseStatus || actualUser.caseStatus || null,
            reviewNote:
              item.reviewNote ||
              actualUser.reviewNote ||
              item.caseMetadata?.review_note ||
              null,
            caseMetadata:
              item.caseMetadata || actualUser.caseMetadata || {},
            name: registrationFullName,
            temp_full_name: registrationFullName,
            phone: actualUser.phone || item.phone || 'Chưa có số',
            email: actualUser.email || item.email || 'Chưa có email',
            // [LAT 4]: Multi-Home C1 dùng caseStatus để quyết định badge/thao tác thay cho users.status (DA_DUYET họ gốc)
            status:
              (item.isMultiHomeCase === true || actualUser.isMultiHomeCase === true) &&
              (item.caseStatus || actualUser.caseStatus)
                ? (item.caseStatus || actualUser.caseStatus) === 'REJECTED'
                  ? 'TU_CHOI'
                  : (item.caseStatus || actualUser.caseStatus) === 'APPROVED' ||
                    (item.caseStatus || actualUser.caseStatus) === 'MERGED'
                  ? 'DA_DUYET'
                  : 'CHO_DUYET'
                : actualUser.status || item.status || 'CHO_DUYET',
            role: actualUser.role || item.role || 'MEMBER',
            // PR-OP-4: từ chối lần cuối (từ BE queryReviewableUsers)
            isFinalRejection:
              actualUser.isFinalRejection === true ||
              item.isFinalRejection === true,

            // 🏛️ LỚP 2: Các trường bổ sung đặc hiệu để Admin đối chiếu hồ sơ (Vừa bổ sung)
            birth_year: registrationBirthYear,
            father_name: registrationFatherName,
            mother_name: registrationMotherName,
            relationship_to_clan: registrationRelationship,

            // 🏛️ LỚP 3: Cấu trúc nested bọc thông tin gốc bảng Users để bảo vệ các logic phụ trợ
            userData: {
              ...actualUser,
              id: actualUser.id || item.id,
              temp_full_name: registrationFullName,
              birth_year: registrationBirthYear,
              father_name: registrationFatherName,
              mother_name: registrationMotherName,
              relationship_to_clan: registrationRelationship
            },

            // 🏛️ LỚP 4: Cấu trúc tenantData tương thích ngược cho Form hiển thị chi tiết dòng họ
            tenantData: actualTenant ? {
              id: actualTenant.id,
              clan_name: actualTenant.name || 'Dòng họ chưa đặt tên',
              status: actualTenant.status || 'CHO_DUYET',
              description: actualTenant.description || actualTenant.notes || 'Hệ thống dữ liệu tộc hệ chính thức',
              slug: actualTenant.slug || '',
              ...actualTenant
            } : null,

            // 🏛️ LỚP 5: Cấu trúc dữ liệu cây gia phả vật lý chuẩn bị cho Issue 2
            memberData: actualMember ? {
              id: actualMember.id,
              branch_name: actualMember.branch_name || snapshot.branch_name || 'Chi cành chủ quản',
              generation: actualMember.generation || 1,
              ...actualMember
            } : null,

            // Giữ lại các nhánh nguyên bản phòng hờ
            temp_snapshot: snapshot,
            tenant: actualTenant,
            member_profile: actualMember
          };
        })
        // Bộ lọc UX thực chiến: Gạt SYSTEM_ADMIN ra ngoài danh sách xử lý của dòng họ
        .filter(u => u && (u.isMultiHomeCase === true || u.role !== 'SYSTEM_ADMIN'))
        .filter(u => {
          if (!currentFilters.caseType) return true;
          const isSetup =
            u.caseType === 'CLAN_SETUP' ||
            String(u.claimCategory || '').startsWith('CLAN_SETUP') ||
            u.role === 'CLAN_ADMIN';
          if (currentFilters.caseType === 'CLAN_SETUP') return isSetup;
          if (currentFilters.caseType === 'MEMBER_JOIN') return !isSetup;
          return true;
        });

      setUsersList(normalizedUsers);
      setPagination(serverPagination);

    } catch (err) {
      console.error('❌ [Fetch Users Error]:', err);

      const code = err?.response?.data?.code || err?.code;
      const msg =
        err?.response?.data?.message ||
        err?.message ||
        'Không thể tải danh sách tài khoản theo bộ lọc.';

      if (code === 'TENANT_NOT_ACTIVATED') {
        setBannerState({
          type: 'warning',
          mode: 'inline',
          title: 'Dòng họ chưa kích hoạt chính thức',
          message:
            msg ||
            'Dòng họ đang tạm ngưng hoặc chưa kích hoạt. Vui lòng hoàn thiện thông tin dòng họ trước khi duyệt thành viên.',
          correlationId: 'Không có',
        });
        setUsersList([]);
        return;
      }

      setBannerState({
        type: 'error',
        mode: 'inline',
        title: 'Không thể tải danh sách hồ sơ',
        message: msg,
        correlationId: 'Không có',
      });
    } finally {
      setLoading(false);
    }
  }, []);

  // Kích hoạt nạp dữ liệu khi bộ lọc hoặc số trang thay đổi
  useEffect(() => {
    fetchReviewableUsers(filters);
  }, [filters.page, fetchReviewableUsers]);

  // Xử lý khi Admin nhấn nút Tìm kiếm trên Form
  const handleSearchSubmit = (e) => {
    e.preventDefault();
    setFilters(prev => ({ ...prev, page: 1 })); // Reset về trang 1 khi lọc mới
    fetchReviewableUsers({ ...filters, page: 1 });
  };

  // Thay đổi trang (Pagination)
  const handlePageChange = (newPage) => {
    if (newPage >= 1 && newPage <= pagination.total_pages) {
      setFilters(prev => ({ ...prev, page: newPage }));
    }
  };

  // Xử lý nộp quyết định thay đổi trạng thái (C2/C2-S qua /auth/*; C1/C1-S qua /membership/cases/:caseId/*)
  const handleApprovalSubmit = async (formData) => {
    setSubmitting(true);
    setBannerState(null);
    try {
      const userId = selectedUser.id;
      const caseId = selectedUser.caseId || null;
      const isMultiHome = selectedUser.isMultiHomeCase === true && Boolean(caseId);
      const adminNote = (formData.adminNote || '').trim();

      if (!adminNote) {
        setBannerState({
          type: 'warning',
          mode: 'inline',
          title: 'Thiếu bút phê quản trị',
          message: 'Vui lòng nhập bút phê / ghi chú.',
          correlationId: 'Không có',
        });
        return;
      }

      if (isMultiHome) {
        if (formData.newStatus === 'RETURN_FOR_REVISION') {
          await membershipApi.returnForRevision(caseId, { adminNote });
          setBannerState({
            type: 'success',
            mode: 'inline',
            title: 'Đã yêu cầu bổ sung hồ sơ',
            message: 'Đã yêu cầu bổ sung hồ sơ Multi-Home (trả về sửa).',
            correlationId: 'Không có',
          });
        } else {
          await membershipApi.approveCase(caseId, {
            newStatus: formData.newStatus,
            adminNote,
            isFinalRejection: formData.isFinalRejection === true,
            targetMemberId: formData.targetMemberId || undefined,
          });
          setBannerState({
            type: 'success',
            mode: 'inline',
            title: 'Đã cập nhật hồ sơ thành công',
            message: formData.isFinalRejection
              ? 'Đã gắn từ chối lần cuối cho hồ sơ Multi-Home.'
              : formData.newStatus === 'DA_DUYET'
                ? 'Đã duyệt hồ sơ gia nhập dòng họ (Multi-Home) thành công!'
                : 'Đã từ chối hồ sơ Multi-Home.',
            correlationId: 'Không có',
          });
        }
      } else {
        // Luồng C2 / C2-S (Guest mới đăng ký)
        if (formData.newStatus === 'RETURN_FOR_REVISION') {
          await apiClient.post('/auth/return-for-revision', {
            userId,
            caseId: caseId || undefined,
            adminNote,
          });
          setBannerState({
            type: 'success',
            mode: 'inline',
            title: 'Đã yêu cầu bổ sung hồ sơ',
            message: 'Đã yêu cầu bổ sung hồ sơ (trả về sửa).',
            correlationId: 'Không có',
          });
        } else {
          await apiClient.post('/auth/process-approval', {
            userId,
            caseId: caseId || undefined,
            newStatus: formData.newStatus,
            adminNote,
            targetMemberId: formData.targetMemberId || undefined,
            isFinalRejection: formData.isFinalRejection === true,
          });
          setBannerState({
            type: 'success',
            mode: 'inline',
            title: 'Đã cập nhật trạng thái tài khoản',
            message: formData.isFinalRejection
              ? 'Đã gắn từ chối lần cuối.'
              : 'Cập nhật trạng thái tài khoản thành công!',
            correlationId: 'Không có',
          });
        }
      }

      setSelectedUser(null);
      fetchReviewableUsers(filters);
    } catch (err) {
      console.error('❌ [Submit Approval Error]:', err);
      const info = extractApiErrorInfo(err);

      // [FUNC-02, TC-FE-02] 400 REFERRER_DECEASED -> Banner modal + refetch
      if (info.status === 400 && info.code === 'REFERRER_DECEASED') {
        setSelectedUser(null);
        setBannerState({
          type: 'warning',
          mode: 'modal',
          title: 'Hồ sơ lùi về NEEDS_REVISION',
          message: `Hồ sơ lùi về NEEDS_REVISION. ${info.message}`,
          correlationId: info.correlationId,
        });
        fetchReviewableUsers(filters);
        return;
      }

      // [ARCH-01, ARCH-04, TC-FE-14] 409 CONCURRENT_TRANSACTION_LOCKED:
      // Không đóng selectedUser để giữ nguyên toàn bộ state form Admin vừa nhập!
      setBannerState({
        type: info.status === 409 ? 'warning' : 'error',
        mode: 'inline',
        title:
          info.status === 409
            ? 'Hồ sơ đang được xử lý đồng thời'
            : 'Thao tác xử lý hồ sơ thất bại',
        message: info.message,
        correlationId: info.correlationId,
        actionButton:
          info.status === 409 ? (
            <button
              type="button"
              onClick={() => handleApprovalSubmit(formData)}
              className="min-h-[48px] rounded-xl bg-amber-600 px-4 py-2 text-base font-bold text-white"
            >
              Thử lại ngay
            </button>
          ) : null,
      });
    } finally {
      setSubmitting(false);
    }
  };

  /**  Giao diện hiển thị khi đang mở Modal/Form Review chi tiết một User ****** */
  //FE-OP-B2
  const isOpProcess =
    String(searchParams.get('process') || '').toUpperCase() === 'OP';
  if (isOpProcess) {
    return <OpApprovalPanel />;
  }

  if (selectedUser) {
    const activeClanName =
      selectedUser?.tenantData?.clan_name ||
      selectedUser?.tenant?.name ||
      sessionTenant?.name ||
      '';
    const targetTenantId =
      selectedUser?.tenantData?.id ||
      selectedUser?.tenant?.id ||
      '';
    const isSelectedClanSetup =
      selectedUser?.caseType === 'CLAN_SETUP' ||
      String(selectedUser?.claimCategory || '').startsWith('CLAN_SETUP');

    return (
      <div className="min-h-screen bg-slate-50">
        <BlockingLoadingOverlay
          isOpen={submitting}
          message="Đang lưu quyết định phê duyệt vào Sổ Cái..."
        />
        <AdminClanLookupDrawer
          isOpen={isClanLookupOpen}
          onClose={() => setIsClanLookupOpen(false)}
          initialQuery={clanLookupInitialQuery}
          clanName={activeClanName}
          mode={clanLookupMode}
          targetTenantId={targetTenantId}
        />
        <div className="max-w-[540px] mx-auto">
          <TenantHeader
            tenant={sessionTenant}
            subtitle={
              isSelectedClanSetup
                ? 'SYSTEM_ADMIN · Duyệt lập dòng họ'
                : 'Phê duyệt người dùng · RP'
            }
          />
          <div className="px-4 py-5">
            {/* Thanh công cụ trên cùng: Quay lại danh sách + Tra cứu sổ họ / Trùng dòng họ [UAT-IMP5 & Mức 2] */}
            <div className="mb-5 flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={() => {
                  setBannerState(null);
                  setIsClanLookupOpen(false);
                  setSelectedUser(null);
                }}
                className="min-h-[48px] h-12 inline-flex items-center gap-1.5 rounded-xl border border-slate-300 bg-white px-3.5 text-base font-bold text-slate-800 whitespace-nowrap hover:bg-slate-50 transition"
              >
                <ChevronLeft size={18} />
                <span>Danh sách</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  if (isSelectedClanSetup) {
                    setClanLookupMode('CLAN_DIRECTORY');
                    setClanLookupInitialQuery(activeClanName);
                  } else {
                    setClanLookupMode('MEMBERS');
                    setClanLookupInitialQuery('');
                  }
                  setIsClanLookupOpen(true);
                }}
                className="min-h-[48px] h-12 inline-flex items-center gap-2 rounded-xl border border-blue-300 bg-blue-50 px-4 text-base font-bold text-blue-800 whitespace-nowrap hover:bg-blue-100 transition"
              >
                <Search size={18} />
                <span>
                  {isSelectedClanSetup
                    ? 'Kiểm tra trùng dòng họ'
                    : 'Tra cứu sổ họ'}
                </span>
              </button>
            </div>

            {bannerState && (
              <PersistentMessageBanner
                type={bannerState.type}
                mode={bannerState.mode}
                title={bannerState.title}
                message={bannerState.message}
                correlationId={bannerState.correlationId}
                actionButton={bannerState.actionButton}
                onClose={() => setBannerState(null)}
              />
            )}

            <UserApprovalForm
              userData={selectedUser}
              loading={submitting}
              onOpenClanLookup={(queryText = '', opts = {}) => {
                setClanLookupMode(
                  opts.mode ||
                    (isSelectedClanSetup ? 'CLAN_DIRECTORY' : 'MEMBERS')
                );
                setClanLookupInitialQuery(queryText);
                setIsClanLookupOpen(true);
              }}
              onCancel={() => {
                setIsClanLookupOpen(false);
                setSelectedUser(null);
              }}
              onSubmit={handleApprovalSubmit}
            />

            <div className="mt-8">
              <AppFooterNav {...footerNav} onLogout={handleLogout} />
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans">
      <div className="mx-auto w-full max-w-[640px]">
        <TenantHeader
          tenant={sessionTenant}
          subtitle="Phê duyệt người dùng · RP"
        />

        <div className="px-4 py-6">
        {bannerState && (
          <PersistentMessageBanner
            type={bannerState.type}
            mode={bannerState.mode}
            title={bannerState.title}
            message={bannerState.message}
            correlationId={bannerState.correlationId}
            actionButton={bannerState.actionButton}
            onClose={() => setBannerState(null)}
          />
        )}
        {/* HEADER ĐỒNG BỘ AUTH_PAGE */}
        <div className="mb-8 text-center">
          <div className="mb-2 flex justify-end">
            <AudioHelpButton text={ADMIN_APPROVAL_RP_HELP} />
          </div>
          <h1 className="text-3xl font-black tracking-tight">Phê duyệt người dùng</h1>
          <p className="mt-2 text-sm font-medium text-slate-600">Tìm kiếm, điều phối vòng đời tài khoản</p>
        </div>

        {/* COMPONENT 1: BỘ LỌC TÌM KIẾM ĐỘNG (MOBILE-FIRST ADAPTIVE) */}
        <form onSubmit={handleSearchSubmit} className="mb-6 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-4 top-3.5 h-4 w-4 text-slate-400" />
              <input
                type="text"
                placeholder="Tìm tên, email, số điện thoại..."
                className="w-full rounded-2xl border border-slate-200 bg-slate-50 py-3 pl-11 pr-4 text-sm font-medium outline-none transition focus:border-indigo-50 focus:bg-white focus:ring-4 focus:ring-indigo-100"
                value={filters.searchKeyword}
                onChange={(e) => setFilters(prev => ({ ...prev, searchKeyword: e.target.value }))}
              />
            </div>
            <button
              type="button"
              onClick={() => setShowFilters(!showFilters)}
              className={`inline-flex items-center justify-center rounded-2xl border p-3.5 transition ${showFilters ? 'bg-indigo-50 border-indigo-200 text-indigo-700' : 'bg-white border-slate-200 text-slate-600'}`}
            >
              <SlidersHorizontal size={18} />
            </button>
          </div>

          {/* VÙNG LỌC NÂNG CAO */}
          {showFilters && (
            <div className="mt-4 pt-4 border-t border-slate-100 space-y-4 animate-fadeIn">
              <div>
                <label className="block text-xs font-black uppercase tracking-wider text-slate-500 mb-1.5">Mối quan tâm Trạng thái</label>
                <select
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm font-bold"
                  value={filters.status}
                  onChange={(e) => setFilters(prev => ({ ...prev, status: e.target.value }))}
                >
                  <option value="">-- Tất cả trạng thái vòng đời --</option>
                  <option value="CHO_DUYET">Hồ sơ chờ duyệt &amp; chờ bổ sung</option>
                  <option value="NEEDS_REVISION">Đã trả yêu cầu bổ sung (Chờ sửa)</option>
                  <option value="DA_DUYET">Tài khoản đang hoạt động bình thường</option>
                  <option value="TU_CHOI">Hồ sơ đăng ký bị từ chối</option>
                  <option value="BI_KHOA">Tài khoản bị khóa (Bảo mật/Kỷ luật)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-black uppercase tracking-wider text-slate-500 mb-1.5">Loại hồ sơ đăng ký</label>
                <select
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm font-bold"
                  value={filters.caseType}
                  onChange={(e) => setFilters(prev => ({ ...prev, caseType: e.target.value }))}
                >
                  <option value="">-- Tất cả loại hồ sơ --</option>
                  <option value="CLAN_SETUP">Lập dòng họ mới (CLAN_SETUP)</option>
                  <option value="MEMBER_JOIN">Gia nhập dòng họ (MEMBER_JOIN)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-black uppercase tracking-wider text-slate-500 mb-1.5">Vai trò nghiệp vụ</label>
                <select
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm font-bold"
                  value={filters.role}
                  onChange={(e) => setFilters(prev => ({ ...prev, role: e.target.value }))}
                >
                  <option value="">-- Tất cả vai trò --</option>
                  <option value="USER">Thành viên liên kết họ (USER)</option>
                  <option value="CLAN_ADMIN">Quản trị viên dòng họ (CLAN_ADMIN)</option>
                </select>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  className="w-full sm:w-auto rounded-xl bg-slate-900 px-6 py-2.5 text-sm font-black text-white shadow-sm hover:bg-slate-800 transition"
                >
                  Áp dụng bộ lọc
                </button>
              </div>
            </div>
          )}
        </form>

        {/* COMPONENT 2: DANH SÁCH DẠNG THẺ CARD */}
        {loading ? (
          <div className="flex flex-col items-center justify-center py-12 rounded-2xl border border-dashed border-slate-200 bg-white">
            <RefreshCw className="h-8 w-8 text-indigo-600 animate-spin" />
            <p className="mt-3 text-sm font-black text-slate-600">Đang quét sổ cái cơ sở dữ liệu...</p>
          </div>
        ) : usersList.length === 0 ? (
          <div className="text-center py-12 rounded-2xl border border-dashed border-slate-200 bg-white p-6">
            <ShieldAlert className="mx-auto h-10 w-10 text-slate-400" />
            <h3 className="mt-4 text-sm font-black text-slate-900">Không tìm thấy tài khoản nào</h3>
            <p className="mt-1 text-xs text-slate-500">Mối quan tâm hiện tại của bạn không khớp với dữ liệu biến động nào trong dòng họ.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {usersList.map((item) => {
              const catMeta = getCaseCategoryMeta(item);
              return (
              <div 
                key={item.caseId || item.id} 
                className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm hover:border-slate-300 transition flex flex-col justify-between gap-4 sm:flex-row sm:items-center"
              >
                <div className="space-y-1.5">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-base font-black tracking-tight text-slate-900">
                      {item.temp_full_name}
                    </span>
                    <span
                      className={`rounded-md border px-2 py-0.5 text-[10px] font-black uppercase tracking-wider ${catMeta.badgeClass}`}
                    >
                      {catMeta.label}
                    </span>
                    <span
                      className={`rounded-full border px-2.5 py-0.5 text-[10px] font-black uppercase tracking-wider ${getStatusBadgeClass(item)}`}
                    >
                      {getStatusLabel(item)}
                    </span>
                  </div>
                  
                  <div className="text-xs font-medium text-slate-500 space-y-0.5">
                    <p>Liên hệ: <span className="font-bold text-slate-700">{item.phone || item.email}</span></p>
                    <p>Dòng họ: <span className="font-bold text-indigo-900">{item.tenantData?.clan_name || 'Chưa phân bổ tộc hệ'}</span></p>
                    
                    {item.caseStatus === 'NEEDS_REVISION' && item.reviewNote && (
                      <p className="mt-1 rounded-lg border border-sky-200 bg-sky-50/80 px-2.5 py-1.5 text-xs font-semibold text-sky-900">
                        Bút phê trả sửa: {item.reviewNote}
                      </p>
                    )}

                    {item.memberData && (
                      <p className="mt-1 inline-flex items-center gap-1 rounded bg-indigo-50/70 px-1.5 py-0.5 text-[11px] font-bold text-indigo-700">
                        🔗 Đã liên kết cây: {item.memberData.branch_name} (Đời {item.memberData.generation})
                      </p>
                    )}
                  </div>
                </div>

                <div className="flex items-center justify-end border-t border-slate-50 pt-3 sm:border-none sm:pt-0">
                  <button
                    onClick={() => setSelectedUser(item)}
                    className={`w-full sm:w-auto inline-flex items-center justify-center gap-1.5 rounded-xl px-4 py-2 text-xs font-black border shadow-sm transition ${
                      item.status === 'CHO_DUYET' 
                        ? 'bg-amber-600 border-amber-600 text-white hover:bg-amber-700' 
                        : item.status === 'BI_KHOA'
                        ? 'bg-white border-slate-200 text-emerald-700 hover:bg-slate-50'
                        : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    {item.status === 'CHO_DUYET' && <UserCheck size={14} />}
                    {item.status === 'BI_KHOA' && <UserCheck size={14} />}
                    {item.status === 'DA_DUYET' && <UserX size={14} />}
                    
                    {item.status === 'CHO_DUYET' ? 'Xét duyệt hồ sơ' : item.status === 'BI_KHOA' ? 'Mở khóa tài khoản' : 'Điều chỉnh quyền'}
                  </button>
                </div>
              </div>
              );
            })}

            {/* COMPONENT 3: PHÂN TRANG THÍCH ỨNG */}
            {pagination.total_pages > 1 && (
              <div className="flex items-center justify-between border-t border-slate-200 pt-4 px-2">
                <span className="text-xs font-bold text-slate-500">
                  Trang {pagination.current_page} / {pagination.total_pages} ({pagination.total_records} hồ sơ)
                </span>
                
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    disabled={pagination.current_page === 1 || loading}
                    onClick={() => handlePageChange(pagination.current_page - 1)}
                    className="inline-flex h-9 w-9 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-600 shadow-sm transition hover:bg-slate-50 disabled:opacity-40 disabled:hover:bg-white"
                  >
                    <ChevronLeft size={16} />
                  </button>
                  <button
                    type="button"
                    disabled={pagination.current_page === pagination.total_pages || loading}
                    onClick={() => handlePageChange(pagination.current_page + 1)}
                    className="inline-flex h-9 w-9 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-600 shadow-sm transition hover:bg-slate-50 disabled:opacity-40 disabled:hover:bg-white"
                  >
                    <ChevronRight size={16} />
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

          <div className="mt-8">
            <AppFooterNav {...footerNav} onLogout={handleLogout} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminUserApprovalPage;