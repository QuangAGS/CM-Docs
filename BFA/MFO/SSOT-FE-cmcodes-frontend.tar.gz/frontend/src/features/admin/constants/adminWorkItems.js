/**
 * PATH       : src/features/admin/constants/adminWorkItems.js
 * DATETIME   : 2026-10-30T07:40:00+07:00
 * VERSION    : 1.3.1-MFO-PLAN
 * DESCRIPTION: Thay «Đóng dấu tờ khai 5 đời» bằng "Xét duyệt thay đổi nhánh phả hệ"
 * - Work items Admin.
 * - Thay «Xét duyệt thay đổi nhánh phả hệ».
 */

export const SYSTEM_ADMIN_WORK_ITEMS = [
  {
    id: 'approval',
    title: 'Phê duyệt người dùng',
    description: 'Duyệt hồ sơ đăng ký tài khoản toàn hệ thống',
    path: '/admin/approval',
    icon: 'Users',
  },
  {
    id: 'op-approval-join',
    title: 'Phê duyệt thành viên',
    description: 'Duyệt thành viên dự bị thành chính thức (nhập tộc / thành lập)',
    path: '/admin/approval?process=OP',
    icon: 'UserCheck',
  },
  {
    id: 'mfo-plan',
    title: 'Xét duyệt thay đổi nhánh phả hệ',
    description: 'Kiểm soát tạo mới, thay đổi các nhánh phả hệ.',
    path: '/admin/mfo/plans',
    icon: 'UserCheck',
  },
  {
    id: 'tenant-directory',
    title: 'Quản trị dòng họ',
    description: 'Danh sách mọi dòng họ, lọc trạng thái, kích hoạt hẹp',
    path: '/admin/tenants',
    icon: 'Building2',
  },
  {
    id: 'tenant-settings',
    title: 'Cài đặt dòng họ',
    description: 'Tên, gia đạo, biểu tượng, logo',
    path: '/admin/tenant/settings',
    icon: 'Settings',
  },
  {
    id: 'tenant-origin',
    title: 'Nơi phát tích',
    description: 'Địa điểm gốc dòng họ do quản trị khai',
    path: '/admin/tenant/origin',
    icon: 'Landmark',
  },
  {
    id: 'member-vital',
    title: 'Tình trạng sống / đã mất',
    description: 'Ghi nhận ngày mất, không mở lại hồ sơ nhập tộc',
    path: '/admin/members/vital',
    icon: 'UserCheck',
  },
  {
    id: 'branches',
    title: 'Chi / ngành',
    description: 'Cây chi, chi cha, không sinh từ sơ đồ người',
    path: '/admin/branches',
    icon: 'GitFork',
  },
];

export const CLAN_ADMIN_WORK_ITEMS = [
  {
    id: 'mfo-plan',
    title: 'Xét duyệt thay đổi nhánh phả hệ',
    description: 'Kiểm soát tạo mới, thay đổi các nhánh phả hệ.',
    path: '/admin/mfo/plans',
    when: ['HOAT_DONG'],
    primary: true,
  },
  {
    id: 'branches',
    title: 'Chi / ngành',
    description: 'Cây chi, chi cha, không sinh từ sơ đồ người',
    path: '/admin/branches',
    icon: 'GitFork',
    when: ['HOAT_DONG', 'TAM_NGUNG'],
  },
  {
    id: 'tenant-origin',
    title: 'Nơi phát tích',
    description: 'Địa điểm gốc dòng họ do quản trị khai',
    path: '/admin/tenant/origin',
    icon: 'Landmark',
  },
  {
    id: 'activate',
    title: 'Kích hoạt dòng họ',
    description: 'Chuyển dòng họ từ tạm ngưng sang hoạt động',
    path: '/admin/tenant/activate',
    icon: 'Building2',
    when: ['TAM_NGUNG'],
    primary: true,
  },
  {
    id: 'approval',
    title: 'Phê duyệt người dùng',
    description: 'Duyệt, từ chối hoặc yêu cầu bổ sung hồ sơ đăng ký',
    path: '/admin/approval',
    icon: 'Users',
    when: ['HOAT_DONG'],
  },
  {
    id: 'op-approval-join',
    title: 'Phê duyệt thành viên',
    description: 'Duyệt thành viên dự bị thành chính thức',
    path: '/admin/approval?process=OP',
    icon: 'UserCheck',
    when: ['HOAT_DONG'],
  },
  {
    id: 'tenant-settings',
    title: 'Cài đặt dòng họ',
    description: 'Tên, gia đạo, biểu tượng, logo',
    path: '/admin/tenant/settings',
    icon: 'Settings',
    when: ['HOAT_DONG', 'TAM_NGUNG'],
  },
  {
    id: 'tree',
    title: 'Xem cây gia phả',
    description: 'Xem và quản lý cây phả hệ của dòng họ',
    path: '/tree',
    icon: 'ShieldCheck',
    when: ['HOAT_DONG'],
  },
  {
    id: 'member-vital',
    title: 'Tình trạng sống / đã mất',
    description: 'Ghi nhận ngày mất, không mở lại hồ sơ nhập tộc',
    path: '/admin/members/vital',
    icon: 'UserCheck',
    when: ['HOAT_DONG'],
  },
];
