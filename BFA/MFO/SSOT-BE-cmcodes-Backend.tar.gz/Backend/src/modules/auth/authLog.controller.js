/*
 * DATETIME: 2026-07-16T12:15:00+07:00
 * PATH: src/modules/auth/authLog.controller.js
 * VERSION: 1.0.0
 * Mục đích: Phục vụ onboarding process.
 */

const authLogService = require('./authLog.service');

const authLogController = {
  // Chỉ dùng cho Admin xem lịch sử
  getLogs: async (req, res) => {
    try {
      const data = await authLogService.getAll();
      res.json({ success: true, data });
    } catch (error) {
      res.status(500).json({ success: false, message: error.message });
    }
  }
};

module.exports = authLogController;