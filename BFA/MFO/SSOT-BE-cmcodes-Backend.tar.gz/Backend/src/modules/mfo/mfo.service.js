/**
 * PATH       : Backend/src/modules/mfo/mfo.service.js
 * DATETIME   : 2026-11-11T17:50:00+07:00
 * VERSION    : 4.8.2-MULTIHOME-SAFE-MUTATE-FINAL
 * DESCRIPTION:
 * - [AMEND-RP-OP-2026-02 V1.2] Lát 3/7 MFO Service hoàn chỉnh:
 *   + tenantIdOf ưu tiên activeTenantId; memberIdOf ưu tiên activeMemberId; isClanOrSys đọc roleInTenant.
 *   + resolveFounderMemberId tra cứu user_member_links theo activeTenantId trước; fallback users có console.warn.
 *   + getPlan, getDraftPayload, createPlan, getOriginTree: Khóa cứng where: { id, tenant_id, deleted_at: null } -> trả về 404 (chống dò quét UUID).
 *   + saveDraft, updatePlan, deleteDraft, createPlan, saveStaging, abortPlan:
 *     Chuyển 100% tx.proposals.update sang updateMany có { id, tenant_id, deleted_at: null } + findFirst đọc lại record,
 *     triệt tiêu hoàn toàn rủi ro TOCTOU và không phụ thuộc vào interactive transaction extension hook.
 *   + getFullMfoSet raw SQL gắn tenant_id tường minh. Không dùng include lồng.
 * - Bảo tồn 100% kiến trúc tương thích SRPF Engine và các thuật toán dựng cây 5L.
 */

const crypto = require('crypto');
const { prisma, withTransaction, audit, tenantContext } = require('../../lib/prisma.js');
const { normalizePlanBody, fail } = require('./mfo.payload.js');
const { mfoWriteBpl, mfoSilentEmit } = require('./mfo.ledger.js');
const { collectHoldMemberIds, findHoldConflict } = require('./mfo.hold.js');
const { expiresAtFor } = require('./mfo.ttl.js');
const { normalizeStaging } = require('./mfo.smp.js');

const OPEN = ['DRAFT', 'PENDING', 'UNDER_REVIEW', 'NEEDS_REVISION'];

/** AMEND-02 V1.2: Actor ID */
function actorIdOf(user) {
  return user && (user.userId || user.id);
}

/** AMEND-02 V1.2: Ưu tiên activeTenantId */
function tenantIdOf(user) {
  // eslint-disable-next-line no-restricted-syntax -- LEGACY-V1: cô lập dữ liệu cũ, sẽ gỡ khi hoàn tất Phase 2
  return user && (user.activeTenantId || user.tenantId || user.tenant_id || null);
}

/** AMEND-02 V1.2: Ưu tiên activeMemberId */
function memberIdOf(user) {
  // eslint-disable-next-line no-restricted-syntax -- LEGACY-V1: cô lập dữ liệu cũ, sẽ gỡ khi hoàn tất Phase 2
  return user && (user.activeMemberId || user.member_id || user.memberId || null);
}

/** AMEND-02 V1.2: Đọc roleInTenant */
function isClanOrSys(user) {
  const r = (user && (user.roleInTenant || user.role)) || '';
  return r === 'CLAN_ADMIN' || r === 'SYSTEM_ADMIN';
}

function avatarUrlOf(memberId, row) {
  if (!memberId || !row) return null;
  const ver = row.checksum || (row.updated_at ? new Date(row.updated_at).getTime() : '1');
  return '/api/media/members/' + memberId + '/avatar?v=' + ver;
}

function assertFullSetInvariants({
  levels,
  nodes,
  targetMemberId,
  selectedCanvasDepth,
  rootCanvasDepth,
  resolvedAncestorSteps,
}) {
  const broken = (code) => {
    const correlationId = crypto.randomUUID();
    console.error('MFO_FULL_SET_INVARIANT_BROKEN', {
      correlation_id: correlationId,
      code,
      target_member_id: targetMemberId,
      selected_canvas_depth: selectedCanvasDepth,
      target_node_count: (nodes || []).filter((node) => node && node.is_target === true).length,
      resolved_ancestor_steps: resolvedAncestorSteps,
      root_canvas_depth: rootCanvasDepth,
    });
    const error = new Error(
      'Không thể dựng khung gia phả nhất quán. Vui lòng thử lại hoặc liên hệ quản trị viên.'
    );
    error.statusCode = 500;
    error.code = 'MFO_FULL_SET_INVARIANT_BROKEN';
    error.correlation_id = correlationId;
    throw error;
  };

  if (!Array.isArray(levels) || levels.length !== 5) broken('MFO_LEVEL_COUNT_INVALID');
  const levelByDepth = new Map(levels.map((level) => [Number(level && level.depth), level]));
  for (let depth = 0; depth <= 4; depth += 1) {
    const level = levelByDepth.get(depth);
    if (!level) broken('MFO_LEVEL_DEPTH_INVALID');
    for (const tree of level.standard_trees || []) {
      if (tree.depth !== depth) broken('MFO_STANDARD_TREE_DEPTH_INVALID');
      if (!tree.parent || !tree.parent.member || tree.parent.member.depth !== depth) {
        broken('MFO_STANDARD_TREE_OWNER_DEPTH_INVALID');
      }
      for (const child of tree.children || []) {
        if (depth === 4 || !child.member || child.member.depth !== depth + 1) {
          broken('MFO_STANDARD_TREE_CHILD_DEPTH_INVALID');
        }
      }
      for (const tab of tree.marriage_tabs || []) {
        for (const child of tab.children || []) {
          if (depth === 4 || !child.member || child.member.depth !== depth + 1) {
            broken('MFO_MARRIAGE_TAB_CHILD_DEPTH_INVALID');
          }
        }
      }
      if (depth === 4) {
        if ((tree.children || []).length > 0) broken('MFO_LAST_LANE_CHILDREN_FORBIDDEN');
        if ((tree.unassigned_children || []).length > 0) broken('MFO_LAST_LANE_UNASSIGNED_CHILDREN_FORBIDDEN');
        if (Number(tree.child_count || 0) !== 0) broken('MFO_LAST_LANE_CHILD_COUNT_INVALID');
        for (const tab of tree.marriage_tabs || []) {
          if ((tab.children || []).length > 0) broken('MFO_LAST_LANE_TAB_CHILDREN_FORBIDDEN');
          if (Number(tab.child_count || 0) !== 0) broken('MFO_LAST_LANE_TAB_CHILD_COUNT_INVALID');
        }
      }
    }
  }
  const targetNodes = (nodes || []).filter((node) => node && node.is_target === true);
  if (targetNodes.length !== 1) broken('MFO_TARGET_NODE_COUNT_INVALID');
  const targetNode = targetNodes[0];
  if (targetNode.role !== 'clan_member' || targetNode.is_clan === false) broken('MFO_TARGET_MUST_BE_CLAN_MEMBER');
  if (String(targetNode.id) !== String(targetMemberId)) broken('MFO_TARGET_IDENTITY_MISMATCH');
  if (targetNode.depth !== selectedCanvasDepth) broken('MFO_TARGET_DEPTH_NOT_PRESERVED');
  const targetLevel = levelByDepth.get(selectedCanvasDepth);
  const targetTrees = ((targetLevel && targetLevel.standard_trees) || []).filter(
    (tree) => tree && tree.parent && tree.parent.member && String(tree.parent.member.id) === String(targetMemberId)
  );
  if (targetTrees.length !== 1) broken('MFO_TARGET_STANDARD_TREE_COUNT_INVALID');
  if (rootCanvasDepth !== selectedCanvasDepth - resolvedAncestorSteps) broken('MFO_ROOT_DEPTH_INVARIANT_BROKEN');
}

async function ensureNoActiveProposal(tx, { tenantId, actorId, excludeId = null }) {
  const where = {
    tenant_id: tenantId,
    requester_user_id: actorId,
    ticket_type: { in: ['MFO_REVIEW', 'BRANCH_REVIEW'] },
    deleted_at: null,
    OR: [
      { status: { in: OPEN } },
      {
        status: 'APPROVED',
        payload: {
          path: ['result_ok'],
          equals: false,
        },
      },
    ],
  };
  if (excludeId) {
    where.id = { not: excludeId };
  }
  const active = await tx.proposals.findFirst({
    where,
    select: { id: true, status: true, payload: true },
  });
  if (active) {
    const isWorkbench = active.status === 'APPROVED' && !active.payload?.result_ok;
    const desc = isWorkbench ? 'đang mở Xưởng kê khai (Gate 1 Approved)' : `ở trạng thái ${active.status}`;
    fail(
      `Đang có hồ sơ #${active.id} ${desc}. Vui lòng hoàn tất hoặc rút/xóa hồ sơ này trước khi mở hồ sơ mới.`,
      409,
      'MFO_ACTIVE_PROPOSAL_EXISTS',
      { active_ticket_id: active.id, status: active.status }
    );
  }
}

function sliceReview(raw) {
  if (!raw || typeof raw !== 'object') return null;
  if (raw.plan || raw.result) return raw;
  return { checks: raw.checks, dirNote: raw.dirNote, extra: raw.extra, note: raw.note };
}

function pickAdminReview(body, row, stage) {
  const prev = sliceReview(((row && row.payload) || {}).admin_review) || {};
  const incoming = (body && (body.admin_review || body.review)) || {};
  const piece =
    incoming.plan || incoming.result
      ? incoming[stage]
      : incoming.checks || incoming.dirNote
        ? incoming
        : null;
  const next = {
    plan: prev.plan || (prev.checks || prev.dirNote ? { checks: prev.checks, dirNote: prev.dirNote, extra: prev.extra } : null),
    result: prev.result || null,
  };
  if (stage === 'plan' && piece) next.plan = piece;
  if (stage === 'result' && piece) next.result = piece;
  return next;
}

/** AMEND-02 V1.2: Tra cứu Founder Member Id chuẩn Multi-Home + console.warn */
async function resolveFounderMemberId(user) {
  const fromJwt = memberIdOf(user);
  if (fromJwt) return fromJwt;
  const uid = actorIdOf(user);
  if (!uid) return null;
  const tid = tenantIdOf(user);
  
  if (tid) {
    const link = await prisma.user_member_links.findFirst({
      where: { user_id: uid, tenant_id: tid, deleted_at: null },
      select: { member_id: true },
    });
    if (link?.member_id) return link.member_id;
  }
  
  console.warn(`⚠️ [resolveFounderMemberId] Cảnh báo: Không tìm thấy activeMemberId hoặc link trong dòng họ đang chọn, fallback về users gốc`, {
    userId: uid,
    tenantId: tid,
  });

  const { basePrisma } = require('../../lib/prisma.js');
  const row = await basePrisma.users.findUnique({
    where: { id: uid },
    select: { member_id: true },
  });
  return (row && row.member_id) || null;
}

async function afterMfo(user, ticket, processType, event, payload) {
  if (!ticket) return;
  await withTransaction(
    {
      tenantId: ticket.tenant_id,
      actorId: actorIdOf(user),
      correlationId: ticket.correlation_id,
    },
    async (tx) =>
      mfoWriteBpl(tx, { processType, user, ticket, payload })
  );
  await mfoSilentEmit(event, ticket, {
    ...(payload || {}),
    userId: actorIdOf(user) || ticket.requester_user_id,
  });
}

const mfoService = {
  getFullMfoSet: async ({ user, targetMemberId, selectedCanvasDepth }) => {
    const startedAt = Date.now();
    const times = {};
    const timed = async (name, job) => {
      const mark = Date.now();
      const value = await job;
      times[name] = Date.now() - mark;
      return value;
    };
    const tenantId = tenantIdOf(user);

    if (!targetMemberId) {
      fail('Thiếu target member ID.', 400, 'MFO_ORIGIN_REQUIRED');
    }

    if (
      selectedCanvasDepth === undefined ||
      selectedCanvasDepth === null ||
      selectedCanvasDepth === ''
    ) {
      fail('Thiếu selected canvas depth.', 400, 'MFO_INVALID_SELECTED_CANVAS_DEPTH');
    }

    const selectedDepth = Number(selectedCanvasDepth);
    if (!Number.isInteger(selectedDepth) || selectedDepth < 0 || selectedDepth > 4) {
      fail('selected_canvas_depth phải là số nguyên từ 0 đến 4.', 400, 'MFO_INVALID_SELECTED_CANVAS_DEPTH');
    }

    const targetId = targetMemberId;
    if (!tenantId) fail('Thiếu tenant.', 400, 'TENANT_REQUIRED');

    const actorId = actorIdOf(user);
    const packed = await timed('branch_ids_ms', prisma.$queryRaw`
      WITH RECURSIVE up AS (
        SELECT id, 0 AS steps
        FROM members
        WHERE id = ${targetId} AND tenant_id = ${tenantId} AND deleted_at IS NULL
        UNION ALL
        SELECT COALESCE(p.father_id, p.mother_id), up.steps + 1
        FROM members p
        JOIN up ON p.id = up.id
        WHERE up.steps < ${selectedDepth}
          AND COALESCE(p.father_id, p.mother_id) IS NOT NULL
          AND p.tenant_id = ${tenantId}
          AND p.deleted_at IS NULL
      ),
      root AS (SELECT id FROM up ORDER BY steps DESC LIMIT 1),
      down AS (
        SELECT id, 0 AS depth FROM root
        UNION ALL
        SELECT c.id, down.depth + 1
        FROM members c
        JOIN down ON c.father_id = down.id OR c.mother_id = down.id
        WHERE down.depth < 4 AND c.tenant_id = ${tenantId} AND c.deleted_at IS NULL
      ),
      branch AS (SELECT DISTINCT id FROM down),
      unions AS (
        SELECT mar.id, mar.husband_id, mar.wife_id, mar.husband_marriage_order, mar.wife_marriage_order,
               mar.status::text AS status, mar.start_date::text AS start_date, mar.end_date::text AS end_date,
               mar.spouse_name_literal, mar.note
        FROM marriages mar
        WHERE mar.deleted_at IS NULL AND mar.tenant_id = ${tenantId}
          AND mar.husband_id IN (SELECT id FROM branch)
        UNION
        SELECT mar.id, mar.husband_id, mar.wife_id, mar.husband_marriage_order, mar.wife_marriage_order,
               mar.status::text, mar.start_date::text, mar.end_date::text,
               mar.spouse_name_literal, mar.note
        FROM marriages mar
        WHERE mar.deleted_at IS NULL AND mar.tenant_id = ${tenantId}
          AND mar.wife_id IN (SELECT id FROM branch)
      ),
      people AS (
        SELECT id FROM branch
        UNION
        SELECT husband_id FROM unions WHERE husband_id IS NOT NULL
        UNION
        SELECT wife_id FROM unions WHERE wife_id IS NOT NULL
      )
      SELECT 'member' AS kind, jsonb_build_object(
        'id', m.id, 'full_name', m.full_name, 'generation', m.generation, 'gender', m.gender::text,
        'father_id', m.father_id, 'mother_id', m.mother_id, 'branch_id', m.branch_id,
        'is_clan', m.is_clan, 'child_type', m.child_type::text, 'sibling_seq', m.sibling_seq,
        'birth_year', m.birth_year, 'note', m.note, 'parent_union_id', m.parent_union_id,
        'tenant_id', m.tenant_id, 'in_branch', m.id IN (SELECT id FROM branch)
      ) AS data
      FROM members m
      WHERE m.deleted_at IS NULL AND m.tenant_id = ${tenantId} AND m.id IN (SELECT id FROM people)
      UNION ALL
      SELECT 'marriage', jsonb_build_object(
        'id', u.id, 'husband_id', u.husband_id, 'wife_id', u.wife_id,
        'husband_marriage_order', u.husband_marriage_order, 'wife_marriage_order', u.wife_marriage_order,
        'status', u.status, 'start_date', u.start_date, 'end_date', u.end_date,
        'spouse_name_literal', u.spouse_name_literal, 'note', u.note
      )
      FROM unions u
      UNION ALL
      SELECT 'avatar', jsonb_build_object('entity_id', med.entity_id, 'checksum', med.checksum, 'updated_at', med.updated_at)
      FROM media med
      WHERE med.deleted_at IS NULL AND med.tenant_id = ${tenantId}
        AND med.entity_type = 'MEMBER' AND med.purpose = 'AVATAR' AND med.is_primary = true
        AND med.entity_id IN (SELECT id FROM people)
      UNION ALL
      SELECT 'hold', hold.data
      FROM (
        SELECT jsonb_build_object('id', p.id, 'status', p.status::text, 'expires_at', p.expires_at) AS data
        FROM proposals p
        WHERE p.deleted_at IS NULL AND p.tenant_id = ${tenantId}
          AND p.status::text IN ('DRAFT', 'PENDING', 'UNDER_REVIEW', 'NEEDS_REVISION', 'APPROVED')
          AND cardinality(p.hold_member_ids) > 0
          AND COALESCE((p.payload->>'result_ok')::boolean, false) = false
          AND p.hold_member_ids && (SELECT COALESCE(array_agg(id::text), ARRAY[]::text[]) FROM branch)
          AND (${actorId}::text IS NULL OR p.requester_user_id <> ${actorId})
        LIMIT 5
      ) hold
    `);
    const rowsOf = (kind) => packed.filter((row) => row.kind === kind).map((row) => row.data || {});
    const people = rowsOf('member');
    const unions = rowsOf('marriage');
    const avatarRows = rowsOf('avatar');
    const holdRows = rowsOf('hold');
    const branchIds = [...new Set(people.filter((row) => row.in_branch).map((row) => row.id).filter(Boolean))];
    if (!people.some((row) => row.id === targetId)) {
      fail('Không tìm thấy thành viên trên sổ.', 404, 'MFO_ORIGIN_NOT_FOUND');
    }
    const now = Date.now();
    const setConflict = holdRows.find((row) => {
      if (!row.expires_at) return true;
      if (['DRAFT', 'NEEDS_REVISION', 'APPROVED'].includes(row.status) && new Date(row.expires_at).getTime() <= now) return false;
      return true;
    }) || null;
    times.branch_members_ms = times.branch_ids_ms;
    times.marriages_ms = times.branch_ids_ms;
    times.avatars_ms = times.branch_ids_ms;
    times.hold_ms = times.branch_ids_ms;
    times.spouses_ms = 0;
    times.founder_ms = 0;
    times.target_ms = 0;
    const buildStartedAt = Date.now();
    if (setConflict) {
      fail('MFO_HOLD_CONFLICT', 409, 'MFO_HOLD_CONFLICT', { expires_at: setConflict.expires_at || null });
    }
    const needed = new Map(people.map((row) => [row.id, row]));
    const targetMember = needed.get(targetId);
    if (!targetMember) {
      fail('Không tìm thấy thành viên trên sổ.', 404, 'MFO_ORIGIN_NOT_FOUND');
    }
    if (String(targetMember.tenant_id) !== String(tenantId)) {
      fail('Thành viên không thuộc dòng họ này.', 403, 'TENANT_MISMATCH');
    }
    if (targetMember.is_clan === false) {
      fail('Thành viên ngoại tộc không thể là M của khung MFO.', 422, 'MFO_TARGET_NOT_CLAN_MEMBER');
    }
    const spouses = people.filter((row) => !row.in_branch);
    const all = [...needed.values()];
    const avatarByMemberId = new Map();
    for (const row of avatarRows) {
      if (!avatarByMemberId.has(row.entity_id)) avatarByMemberId.set(row.entity_id, row);
    }
    const unionById = new Map(unions.map((union) => [union.id, union]));

    const isClanMember = (member) => !member || member.is_clan !== false;

    const byId = new Map(all.map((member) => [member.id, member]));

    const childrenOfMap = new Map();

    const addChild = (parentId, childId) => {
      if (!parentId || !childId) return;

      if (!childrenOfMap.has(parentId)) {
        childrenOfMap.set(parentId, new Set());
      }

      childrenOfMap.get(parentId).add(childId);
    };

    for (const member of all) {
      if (!isClanMember(member)) continue;

      addChild(member.father_id, member.id);
      addChild(member.mother_id, member.id);
    }

    const partnersOf = new Map();

    const pushPartner = (ownerId, partner, meta = {}) => {
      if (!ownerId || !partner) return;
      if (partner.id && String(partner.id) === String(ownerId)) return;

      if (!partnersOf.has(ownerId)) {
        partnersOf.set(ownerId, []);
      }

      const bag = partnersOf.get(ownerId);

      const partnerIdentity = partner.id
        ? `member:${partner.id}`
        : `literal:${String(partner.full_name || '').trim().toLowerCase()}`;

      const unionIdentity = meta.unionId
        ? `union:${meta.unionId}`
        : 'union:none';

      const key = `${unionIdentity}:${partnerIdentity}`;

      if (bag.some((item) => item._key === key)) {
        return;
      }

      bag.push({
        ...partner,
        _key: key,
        _union_id: meta.unionId || null,
        _ord:
          meta.ord !== null &&
          meta.ord !== undefined
            ? Number(meta.ord)
            : 9999,
        _status: meta.status || null,
        _is_literal: !partner.id,
      });
    };

    for (const union of unions) {
      const husband = union.husband_id
        ? byId.get(union.husband_id)
        : null;

      const wife = union.wife_id
        ? byId.get(union.wife_id)
        : null;

      if (union.husband_id) {
        if (wife) {
          pushPartner(
            union.husband_id,
            wife,
            {
              unionId: union.id,
              ord: union.husband_marriage_order,
              status: union.status,
            }
          );
        } else if (union.spouse_name_literal) {
          pushPartner(
            union.husband_id,
            {
              id: null,
              full_name: union.spouse_name_literal,
              is_clan: false,
            },
            {
              unionId: union.id,
              ord: union.husband_marriage_order,
              status: union.status,
            }
          );
        }
      }

      if (union.wife_id) {
        if (husband) {
          pushPartner(
            union.wife_id,
            husband,
            {
              unionId: union.id,
              ord: union.wife_marriage_order,
              status: union.status,
            }
          );
        } else if (union.spouse_name_literal) {
          pushPartner(
            union.wife_id,
            {
              id: null,
              full_name: union.spouse_name_literal,
              is_clan: false,
            },
            {
              unionId: union.id,
              ord: union.wife_marriage_order,
              status: union.status,
            }
          );
        }
      }
    }

    const isUnknownMember = (member) => {
      const note = String(member?.note || '');
      const name = String(member?.full_name || '');

      return (
        note.includes('[UM]') ||
        /^chưa rõ/i.test(name)
      );
    };

    const packMember = (member, extra = {}) => ({
      id: member?.id || null,
      full_name: member?.full_name || null,
      is_unknown: isUnknownMember(member),
      generation:
        member?.generation !== null &&
        member?.generation !== undefined
          ? member.generation
          : null,
      gender: member?.gender || null,
      father_id: member?.father_id || null,
      mother_id: member?.mother_id || null,
      branch_id: member?.branch_id || null,
      is_clan: member?.is_clan !== false,
      child_type: member?.child_type || null,
      parent_union_id: member?.parent_union_id || null,
      avatar_url: avatarUrlOf(member?.id, avatarByMemberId.get(member?.id)),
      sibling_seq:
        member?.sibling_seq !== null &&
        member?.sibling_seq !== undefined
          ? member.sibling_seq
          : null,
      birth_year:
        member?.birth_year !== null &&
        member?.birth_year !== undefined
          ? member.birth_year
          : null,
      ...extra,
    });

    const compareSiblings = (aId, bId) => {
      const a = byId.get(aId);
      const b = byId.get(bId);

      const seqA = a?.sibling_seq ?? 999999;
      const seqB = b?.sibling_seq ?? 999999;

      if (seqA !== seqB) {
        return seqA - seqB;
      }

      const yearA = a?.birth_year ?? 999999;
      const yearB = b?.birth_year ?? 999999;

      if (yearA !== yearB) {
        return yearA - yearB;
      }

      return String(a?.full_name || '').localeCompare(
        String(b?.full_name || ''),
        'vi'
      );
    };

    const getSortedChildrenIds = (parentId) => {
      return [...(childrenOfMap.get(parentId) || new Set())]
        .filter((id) => byId.has(id))
        .sort(compareSiblings);
    };

    const getSortedPartners = (memberId, depth) => {
      return [...(partnersOf.get(memberId) || [])]
        .sort((a, b) => {
          if (a._ord !== b._ord) {
            return a._ord - b._ord;
          }

          return String(a.full_name || '').localeCompare(
            String(b.full_name || ''),
            'vi'
          );
        })
        .map((partner) =>
          packMember(partner, {
            depth,
            role: 'partner',
            source: partner.id ? 'marriage' : 'literal',
            union_id: partner._union_id,
            union_status: partner._status,
            is_literal: partner._is_literal,
            position: 'right',
            source: partner.id ? 'member' : 'literal',
          })
        );
    };

    let rootNode = targetMember;
    let actualAncestorSteps = 0;
    let rootDepth = selectedDepth;

    const ancestorPathFromRootToTarget = [targetMember.id];

    while (actualAncestorSteps < selectedDepth) {
      const parentId = [
        rootNode.father_id,
        rootNode.mother_id,
      ].find((id) => id && byId.has(id));

      if (!parentId) {
        break;
      }

      rootNode = byId.get(parentId);
      actualAncestorSteps += 1;
      rootDepth -= 1;

      ancestorPathFromRootToTarget.unshift(rootNode.id);
    }

    const levels = Array.from({ length: 5 }, (_, depth) => ({
      depth,
      is_empty: true,
      placeholder: {
        kind: 'empty_couple',
        clan_member: null,
        spouse: null,
      },
      member_ids: [],
      nodes: [],
      standard_trees: [],
    }));

    const nodes = [];
    const nodeDepthById = new Map();
    const seenNodeIds = new Set();

    let currentLevelIds = [rootNode.id];

    for (let depth = rootDepth; depth <= 4; depth += 1) {
      const nextLevelIds = [];
      const nextLevelSeen = new Set();

      for (const memberId of currentLevelIds) {
        if (seenNodeIds.has(memberId)) {
          continue;
        }

        const member = byId.get(memberId);

        if (!member || !isClanMember(member)) {
          continue;
        }

        seenNodeIds.add(memberId);
        nodeDepthById.set(memberId, depth);

        const partners = getSortedPartners(memberId, depth);

        const node = packMember(member, {
          depth,
          role: 'clan_member',
          position: 'left',
          is_origin: memberId === rootNode.id,
          is_target: memberId === targetMember.id,
          partners,
        });

        nodes.push(node);

        levels[depth].is_empty = false;
        levels[depth].member_ids.push(memberId);
        levels[depth].nodes.push(node);

        if (depth >= 4) {
          continue;
        }

        for (const childId of getSortedChildrenIds(memberId)) {
          if (
            seenNodeIds.has(childId) ||
            nextLevelSeen.has(childId)
          ) {
            continue;
          }

          nextLevelSeen.add(childId);
          nextLevelIds.push(childId);
        }
      }

      currentLevelIds = nextLevelIds;

      if (currentLevelIds.length === 0 && depth < 4) {
        currentLevelIds = [];
      }
    }

    const makeStandardTree = (ownerNode) => {
      const ownerId = ownerNode.id;
      const ownerDepth = ownerNode.depth;

      const childDepth = ownerDepth + 1;

      const childIds =
        childDepth <= 4
          ? getSortedChildrenIds(ownerId)
              .filter(
                (childId) =>
                  nodeDepthById.get(childId) === childDepth
              )
          : [];

      const children = childIds
        .map((childId) => {
          const child = byId.get(childId);

          if (!child) return null;

          return {
            member: packMember(child, {
              depth: childDepth,
              role: 'clan_member',
              position: 'left',
              is_target: child.id === targetMember.id,
            }),
            partners: getSortedPartners(child.id, childDepth),
          };
        })
        .filter(Boolean);

      const ownerUnions = unions
        .filter((u) => u.husband_id === ownerId || u.wife_id === ownerId)
        .map((u) => {
          const ownerOrder = u.husband_id === ownerId
            ? u.husband_marriage_order
            : u.wife_marriage_order;
          const canonical = !!(u.husband_id && u.wife_id);
          const partnerMember = u.husband_id === ownerId
            ? (u.wife_id ? byId.get(u.wife_id) : null)
            : (u.husband_id ? byId.get(u.husband_id) : null);
          const partner = partnerMember
            ? packMember(partnerMember, {
                depth: ownerDepth,
                role: 'partner',
                position: 'right',
                source: 'member',
              })
            : {
                id: null,
                full_name: u.spouse_name_literal || null,
                role: 'partner',
                position: 'right',
                source: 'literal',
                is_clan: false,
                parent_union_id: null,
                avatar_url: null,
              };
          return { u, ownerOrder, canonical, partner };
        })
        .sort((a, b) => {
          const oa = a.ownerOrder == null ? 999999 : a.ownerOrder;
          const ob = b.ownerOrder == null ? 999999 : b.ownerOrder;
          if (oa !== ob) return oa - ob;
          const da = a.u.start_date ? new Date(a.u.start_date).getTime() : 8640000000000000;
          const db = b.u.start_date ? new Date(b.u.start_date).getTime() : 8640000000000000;
          if (da !== db) return da - db;
          return String(a.u.id).localeCompare(String(b.u.id));
        });
      const tabChildren = new Map();
      const unassigned = [];
      for (const child of children) {
        const uid = child.member.parent_union_id;
        if (!uid) {
          unassigned.push({ ...child, reason: 'PARENT_UNION_UNSET' });
          continue;
        }
        const union = unionById.get(uid);
        if (!union) {
          unassigned.push({ ...child, reason: 'PARENT_UNION_NOT_FOUND' });
          continue;
        }
        if (!union.husband_id || !union.wife_id) {
          unassigned.push({ ...child, reason: 'PARENT_UNION_LITERAL_NOT_ASSIGNABLE' });
          continue;
        }
        if (union.husband_id !== ownerId && union.wife_id !== ownerId) {
          unassigned.push({ ...child, reason: 'PARENT_UNION_NOT_OWNED_BY_ST' });
          continue;
        }
        if (!tabChildren.has(uid)) tabChildren.set(uid, []);
        tabChildren.get(uid).push(child);
      }
      const marriage_tabs = ownerUnions.map(({ u, ownerOrder, canonical, partner }) => ({
        union_id: u.id,
        owner_marriage_order: ownerOrder == null ? null : ownerOrder,
        union_status: u.status || null,
        supports_parent_union_assignment: canonical,
        partner,
        children: tabChildren.get(u.id) || [],
        child_count: (tabChildren.get(u.id) || []).length,
      }));
      const tree = {
        id: `st:${ownerDepth}:${ownerId}`,
        depth: ownerDepth,
        kind: 'standard_tree',
        parent: {
          member: packMember(byId.get(ownerId), {
            depth: ownerDepth,
            role: 'clan_member',
            position: 'left',
            is_origin: ownerId === rootNode.id,
            is_target: ownerId === targetMember.id,
          }),
          partners: getSortedPartners(ownerId, ownerDepth),
        },
        children,
        child_count: children.length,
        marriage_tabs,
        unassigned_children: unassigned,
      };
      if (ownerDepth === 4) {
        tree.children = [];
        tree.child_count = 0;
        tree.unassigned_children = [];
        tree.marriage_tabs = marriage_tabs.map((tab) => ({
          ...tab,
          children: [],
          child_count: 0,
        }));
      }
      return tree;
    };

    for (const level of levels) {
      level.standard_trees = level.nodes.map(makeStandardTree);
    }

    const emptyAncestorDepths = [];

    for (let depth = 0; depth < rootDepth; depth += 1) {
      emptyAncestorDepths.push(depth);
    }

    const mwlId = null;

    let mwlK = null;
    let mwlReason = 'no_mwl';
    let pathFromOriginToMwl = [];

    if (mwlId) {
      const mwl = byId.get(mwlId);

      if (!mwl) {
        mwlReason = 'mwl_not_found';
      } else if (mwl.is_clan === false) {
        mwlReason = 'ngoai_toc';
      } else if (mwlId === rootNode.id) {
        mwlK = 0;
        mwlReason = 'self';
        pathFromOriginToMwl = [rootNode.id];
      } else {
        const visited = new Set([mwlId]);

        const queue = [
          {
            id: mwlId,
            steps: 0,
            trailFromMwl: [mwlId],
          },
        ];

        let hit = null;
        let cursor = 0;

        while (cursor < queue.length && !hit) {
          const current = queue[cursor];
          cursor += 1;

          if (current.steps > 32) {
            continue;
          }

          if (current.id === rootNode.id) {
            hit = current;
            break;
          }

          const currentMember = byId.get(current.id);

          if (!currentMember) {
            continue;
          }

          for (const parentId of [
            currentMember.father_id,
            currentMember.mother_id,
          ]) {
            if (!parentId || visited.has(parentId)) {
              continue;
            }

            const parent = byId.get(parentId);

            if (!parent || parent.is_clan === false) {
              continue;
            }

            visited.add(parentId);

            queue.push({
              id: parentId,
              steps: current.steps + 1,
              trailFromMwl: [
                ...current.trailFromMwl,
                parentId,
              ],
            });
          }
        }

        if (hit) {
          mwlK = hit.steps;
          mwlReason = mwlK <= 4 ? 'on_tree' : 'too_far';

          pathFromOriginToMwl = [
            ...hit.trailFromMwl,
          ].reverse();
        } else {
          mwlReason = 'not_on_tree';
        }
      }
    }

    const targetNode = nodes.find(
      (node) => node.id === targetMember.id
    );

    const resolvedRoot = {
      member_id: rootNode.id,
      full_name: rootNode.full_name,
      root_canvas_depth: rootDepth,
    };

    assertFullSetInvariants({
      levels,
      nodes,
      targetMemberId: targetMember.id,
      selectedCanvasDepth: selectedDepth,
      rootCanvasDepth: rootDepth,
      resolvedAncestorSteps: actualAncestorSteps,
    });

    times.build_payload_ms = Date.now() - buildStartedAt;
    times.service_total_ms = Date.now() - startedAt;
    console.info('[MFO_FULL_SET_TIMING]', {
      target_ms: times.target_ms || 0,
      branch_ids_ms: times.branch_ids_ms || 0,
      founder_ms: times.founder_ms || 0,
      branch_members_ms: times.branch_members_ms || 0,
      marriages_ms: times.marriages_ms || 0,
      hold_ms: times.hold_ms || 0,
      spouses_ms: times.spouses_ms || 0,
      avatars_ms: times.avatars_ms || 0,
      build_payload_ms: times.build_payload_ms || 0,
      service_total_ms: times.service_total_ms || 0,
      branch_count: branchIds.length,
      spouse_count: spouses.length,
      union_count: unions.length,
      node_count: nodes.length,
    });

    return {
      request_context: {
        target_member_id: targetMember.id,
        selected_canvas_depth: selectedDepth,
      },

      resolved_root: resolvedRoot,

      origin: {
        id: rootNode.id,
        full_name: rootNode.full_name,
        generation: rootNode.generation,
        branch_id: rootNode.branch_id,
        is_clan: rootNode.is_clan !== false,
        root_canvas_depth: rootDepth,
      },

      target: {
        member_id: targetMember.id,
        id: targetMember.id,
        full_name: targetMember.full_name,
        selected_canvas_depth: selectedDepth,
        rendered_canvas_depth: selectedDepth,
        resolved_ancestor_steps: actualAncestorSteps,
        selected_depth: selectedDepth,
        actual_depth: targetNode?.depth ?? selectedDepth,
        is_position_preserved: true,
      },

      window: {
        min_depth: 0,
        max_depth: 4,
        depth_count: 5,
        selected_depth: selectedDepth,
        root_depth: rootDepth,
        actual_ancestor_steps: actualAncestorSteps,
        empty_ancestor_depths: emptyAncestorDepths,
      },

      actual_k: actualAncestorSteps,
      target_member_id: targetMember.id,
      window_depth: 4,

      rule:
        'fixed_5_levels+selected_depth_anchor+is_clan+marriages+standard_tree_clusters',

      levels,

      nodes,

      hold_member_ids: nodes.map((node) => node && node.id).filter(Boolean),

      ancestor_path_from_root_to_target: ancestorPathFromRootToTarget,

      contract_version: '2.2',
      deprecated_fields: [
        'origin.id',
        'origin.root_canvas_depth',
        'target.selected_depth',
        'target.actual_depth',
        'window.selected_depth',
        'window.root_depth',
        'window.actual_ancestor_steps',
        'actual_k',
      ],
    };
  },

  saveDraft: async ({ user, body, correlationId }) => {
    const actor = actorIdOf(user);
    if (!actor) fail('Thiếu người thực hiện.', 401, 'UNAUTHENTICATED');
    const tenantId = tenantIdOf(user);
    if (!tenantId) fail('Thiếu tenant.', 400, 'TENANT_REQUIRED');

    const targetMemberId = body.target_member_id || body.origin_member_id;
    if (!targetMemberId) {
      fail('Lưu nháp bắt buộc chọn Thành viên mốc M (target_member_id).', 400, 'MFO_TARGET_REQUIRED');
    }

    const started = Date.now();
    const times = {};
    const selectedCanvasDepth = Number(body.selected_canvas_depth ?? body.k ?? 0);
    const now = new Date();
    const keepId = body.ticket_id || body.ticketId || null;
    const readStarted = Date.now();
    const holdIds = collectHoldMemberIds({
      hold_member_ids: body.hold_member_ids,
      nodes: body.nodes,
      levels: body.levels,
      lines: body.lines,
      canvas_delta: body.canvas_delta,
      target_member_id: targetMemberId,
    });
    const holdList = holdIds.length ? holdIds : ['00000000-0000-0000-0000-000000000000'];
    const rows = await prisma.$queryRaw`
      SELECT m.id AS member_id, m.tenant_id, m.deleted_at,
             t.id, t.status, t.updated_at, t.correlation_id, t.expires_at, t.plan_ok, t.result_submitted, t.result_ok, t.next_attempt,
             h.id AS hold_id, h.expires_at AS hold_expires
      FROM members m
      LEFT JOIN LATERAL (
        SELECT id, status, updated_at, correlation_id, expires_at,
               (payload->>'plan_ok')::boolean AS plan_ok,
               (payload->>'result_submitted')::boolean AS result_submitted,
               (payload->>'result_ok')::boolean AS result_ok,
               COALESCE((SELECT MAX(attempt_no) FROM business_process_logs WHERE correlation_id = proposals.correlation_id), 0) + 1 AS next_attempt
        FROM proposals
        WHERE deleted_at IS NULL AND tenant_id = ${tenantId}
          AND (
            (${keepId}::text IS NOT NULL AND id = ${keepId})
            OR (${keepId}::text IS NULL AND requester_user_id = ${actor}
                AND ticket_type = 'MFO_REVIEW'
                AND status IN ('DRAFT', 'NEEDS_REVISION', 'APPROVED'))
          )
        ORDER BY updated_at DESC
        LIMIT 1
      ) t ON true
      LEFT JOIN LATERAL (
        SELECT id, expires_at
        FROM proposals
        WHERE deleted_at IS NULL AND tenant_id = ${tenantId}
          AND status::text IN ('DRAFT', 'PENDING', 'UNDER_REVIEW', 'NEEDS_REVISION', 'APPROVED')
          AND cardinality(hold_member_ids) > 0
          AND COALESCE((payload->>'result_ok')::boolean, false) = false
          AND hold_member_ids && ${holdList}::text[]
          AND (${keepId}::text IS NULL OR id <> ${keepId})
          AND requester_user_id <> ${actor}
          AND NOT (
            status::text IN ('DRAFT', 'NEEDS_REVISION', 'APPROVED')
            AND expires_at IS NOT NULL AND expires_at <= NOW()
          )
        LIMIT 1
      ) h ON true
      WHERE m.id = ${targetMemberId}
      LIMIT 1
    `;
    times.read_ms = Date.now() - readStarted;
    const row = Array.isArray(rows) ? rows[0] : null;
    const targetMember = row && row.member_id ? { id: row.member_id, tenant_id: row.tenant_id, deleted_at: row.deleted_at } : null;
    const currentProposal = row && row.id ? row : null;
    const existingDraft = currentProposal;
    const draftConflict = row && row.hold_id ? { id: row.hold_id, expires_at: row.hold_expires } : null;

    if (!targetMember || targetMember.deleted_at) {
      fail('Thành viên mốc M không tồn tại trên sổ.', 404, 'MFO_TARGET_NOT_FOUND');
    }
    if (String(targetMember.tenant_id) !== String(tenantId)) {
      fail('Thành viên mốc M không thuộc dòng họ này.', 403, 'TENANT_MISMATCH');
    }
    if (currentProposal) {
      const st = currentProposal.status;
      const p = currentProposal.payload || {};
      const isEditable = st === 'DRAFT' || st === 'NEEDS_REVISION' || (st === 'APPROVED' && p.plan_ok && !p.result_submitted && !p.result_ok);
      if (!isEditable) {
        fail(`Tờ trình đang ở trạng thái [${st}], không thể lưu sửa nháp!`, 409, 'MFO_PROPOSAL_LOCKED');
      }
    }
    const kept = currentProposal || {};
    const payloadToSave = {
      kind: 'PLAN',
      target_member_id: targetMemberId,
      origin_member_id: targetMemberId,
      selected_canvas_depth: selectedCanvasDepth,
      k: selectedCanvasDepth,
      lines: Array.isArray(body.lines) ? body.lines : [],
      canvas_delta: body.canvas_delta || {
        draft_children: [],
        draft_spouses: [],
        node_positions_x: {},
      },
      smp_staging_data: body.smp_staging_data || kept.smp_staging_data || {},
      graph_snapshot: body.graph_snapshot || null,
      init_scs: body.init_scs || body.diff_summary || [],
      diff_summary: body.diff_summary || body.init_scs || [],
      plan_ok: kept.plan_ok === true,
      result_submitted: kept.result_submitted === true,
      result_ok: kept.result_ok === true,
    };
    const holdMemberIds = holdIds;
    if (draftConflict) {
      fail(
        'MFO_HOLD_CONFLICT',
        409,
        'MFO_HOLD_CONFLICT',
        { expires_at: draftConflict.expires_at || null }
      );
    }
    if (existingDraft && existingDraft.expires_at && new Date(existingDraft.expires_at).getTime() <= now.getTime() && existingDraft.status === 'DRAFT') {
      fail('Bản nháp đã hết hạn. Hãy mở tờ mới.', 409, 'MFO_HOLD_EXPIRED');
    }

    const corr = correlationId || existingDraft?.correlation_id || crypto.randomUUID();

    const saved = await withTransaction(
      { tenantId, actorId: actor, correlationId: corr },
      async (tx) => {
        let ticket;

        const rowToUpdate = currentProposal || (existingDraft && existingDraft.status === 'DRAFT' ? existingDraft : null);
        if (rowToUpdate) {
          if (body.updated_at) {
            const clientTime = new Date(body.updated_at).getTime();
            const serverTime = new Date(rowToUpdate.updated_at).getTime();
            if (Math.abs(clientTime - serverTime) > 2000) {
              fail('Bản nháp đã được cập nhật từ thiết bị khác. Vui lòng nạp lại trang!', 409, 'OPTIMISTIC_LOCK_CONFLICT');
            }
          }

          // AMEND-02 V1.2: updateMany có tenant_id + deleted_at bảo đảm cách ly tuyệt đối
          await tx.proposals.updateMany({
            where: { id: rowToUpdate.id, tenant_id: tenantId, deleted_at: null },
            data: {
              target_id: targetMemberId,
              payload: payloadToSave,
              hold_member_ids: holdMemberIds,
              updated_at: now,
              changed_by: actor,
            },
          });
          ticket = await tx.proposals.findFirst({
            where: { id: rowToUpdate.id, tenant_id: tenantId, deleted_at: null },
            select: { id: true, updated_at: true, expires_at: true, correlation_id: true, requester_user_id: true, tenant_id: true, target_id: true, status: true },
          });

          if (audit && typeof audit.create === 'function') {
            await audit.create(tx, {
              tableName: 'proposals',
              recordId: ticket.id,
              action: 'CAP_NHAT',
              tenantId,
              changedBy: actor,
              correlationId: corr,
              oldData: {
                target_id: rowToUpdate.target_id,
                updated_at: rowToUpdate.updated_at,
              },
              newData: {
                target_id: ticket.target_id,
                updated_at: ticket.updated_at,
                lines_count: payloadToSave.lines.length,
              },
              changeReason: `Cập nhật bản nháp MFO #${ticket.id}`,
            });
          }
        } else {
          ticket = await tx.proposals.create({
            data: {
              tenant_id: tenantId,
              ticket_type: 'MFO_REVIEW',
              status: 'DRAFT',
              requester_user_id: actor,
              target_table: 'members',
              target_id: targetMemberId,
              payload: payloadToSave,
              hold_member_ids: holdMemberIds,
              expires_at: expiresAtFor('DRAFT', now),
              payload_schema_version: 2,
              correlation_id: corr,
              changed_by: actor,
            },
            select: { id: true, updated_at: true, expires_at: true, correlation_id: true, requester_user_id: true, tenant_id: true, target_id: true, status: true },
          });

          if (audit && typeof audit.create === 'function') {
            await audit.create(tx, {
              tableName: 'proposals',
              recordId: ticket.id,
              action: 'THEM_MOI',
              tenantId,
              changedBy: actor,
              correlationId: corr,
              oldData: null,
              newData: {
                id: ticket.id,
                target_id: ticket.target_id,
                status: ticket.status,
                ticket_type: 'MFO_REVIEW',
              },
              changeReason: `Tạo mới bản nháp MFO 5L neo tại mốc ${targetMemberId}`,
            });
          }
        }

        await mfoWriteBpl(tx, {
          processType: 'MFO_PLAN_SUBMIT',
          user,
          ticket,
          attemptNo: currentProposal && currentProposal.next_attempt,
          payload: {
            action: 'MFO_DRAFT_SAVED',
            ticket_id: ticket.id,
            target_member_id: targetMemberId,
            saved_at: now.toISOString(),
          },
        });

        return {
          ticket,
          updated_at: ticket.updated_at.toISOString(),
        };
      }
    );
    times.write_ms = Date.now() - started - (times.read_ms || 0);
    times.service_total_ms = Date.now() - started;
    console.info('[MFO_DRAFT_TIMING]', times);
    return saved;
  },

  updatePlan: async ({ user, ticketId, body, correlationId }) => {
    const actor = actorIdOf(user);
    if (!actor) fail('Thiếu người thực hiện.', 401, 'UNAUTHENTICATED');
    const tenantId = tenantIdOf(user);
    if (!tenantId) fail('Thiếu tenant.', 400, 'TENANT_REQUIRED');

    if (!ticketId) {
      fail('Thiếu ticketId cần cập nhật.', 400, 'MFO_TICKET_REQUIRED');
    }

    const proposal = await prisma.proposals.findFirst({
      where: {
        id: ticketId,
        tenant_id: tenantId,
        deleted_at: null,
      },
    });

    if (!proposal) {
      fail('Không tìm thấy Tờ trình/Bản nháp cần cập nhật.', 404, 'MFO_LOT_NOT_FOUND');
    }

    if (!isClanOrSys(user) && String(proposal.requester_user_id) !== String(actor)) {
      fail('Bạn không có quyền chỉnh sửa tờ trình này.', 403, 'FORBIDDEN');
    }

    const status = String(proposal.status).toUpperCase();

    const targetMemberId = body.target_member_id || body.origin_member_id || proposal.target_id;
    const selectedCanvasDepth = Number(body.selected_canvas_depth ?? body.k ?? proposal.payload?.selected_canvas_depth ?? 0);
    const now = new Date();

    const existingPayload = proposal.payload || {};
    const gate2Open = status === 'APPROVED' && existingPayload.plan_ok === true && !existingPayload.result_submitted && !existingPayload.result_ok;
    if (status !== 'DRAFT' && status !== 'NEEDS_REVISION' && !gate2Open) {
      fail(`Tờ trình đang ở trạng thái [${status}]. Không thể chỉnh sửa!`, 409, 'MFO_NOT_EDITABLE_STATE');
    }
    const updatedPayload = {
      ...existingPayload,
      kind: 'PLAN',
      target_member_id: targetMemberId,
      origin_member_id: targetMemberId,
      selected_canvas_depth: selectedCanvasDepth,
      k: selectedCanvasDepth,
      lines: Array.isArray(body.lines) ? body.lines : (existingPayload.lines || []),
      canvas_delta: body.canvas_delta || existingPayload.canvas_delta || {
        draft_children: [],
        draft_spouses: [],
        node_positions_x: {},
      },
      smp_staging_data: body.smp_staging_data || existingPayload.smp_staging_data || {},
      graph_snapshot: body.graph_snapshot || existingPayload.graph_snapshot || null,
      init_scs: body.init_scs || body.diff_summary || existingPayload.init_scs || [],
      diff_summary: body.diff_summary || body.init_scs || existingPayload.diff_summary || [],
      plan_ok: existingPayload.plan_ok === true,
      result_submitted: existingPayload.result_submitted === true,
      result_ok: existingPayload.result_ok === true,
    };

    const holdMemberIds = collectHoldMemberIds({
      ...updatedPayload,
      hold_member_ids: body.hold_member_ids || existingPayload.hold_member_ids,
    });

    const corr = correlationId || proposal.correlation_id || crypto.randomUUID();

    return await withTransaction(
      { tenantId, actorId: actor, correlationId: corr },
      async (tx) => {
        // AMEND-02 V1.2: updateMany có tenant_id + deleted_at bảo đảm cách ly tuyệt đối
        await tx.proposals.updateMany({
          where: { id: ticketId, tenant_id: tenantId, deleted_at: null },
          data: {
            target_id: targetMemberId,
            payload: updatedPayload,
            hold_member_ids: holdMemberIds,
            updated_at: now,
            changed_by: actor,
          },
        });
        const updatedProposal = await tx.proposals.findFirst({
          where: { id: ticketId, tenant_id: tenantId, deleted_at: null },
        });

        if (audit && typeof audit.create === 'function') {
          await audit.create(tx, {
            tableName: 'proposals',
            recordId: updatedProposal.id,
            action: 'CAP_NHAT',
            tenantId,
            changedBy: actor,
            correlationId: corr,
            oldData: {
              target_id: proposal.target_id,
              status: proposal.status,
            },
            newData: {
              target_id: updatedProposal.target_id,
              status: updatedProposal.status,
            },
            changeReason: `Cập nhật nội dung tờ trình MFO #${updatedProposal.id}`,
          });
        }

        await mfoWriteBpl(tx, {
          processType: 'MFO_PLAN_SUBMIT',
          user,
          ticket: updatedProposal,
          payload: {
            action: 'MFO_DRAFT_UPDATED',
            ticket_id: updatedProposal.id,
            target_member_id: targetMemberId,
            updated_at: now.toISOString(),
          },
        });

        return {
          ticket: updatedProposal,
          updated_at: updatedProposal.updated_at.toISOString(),
        };
      }
    );
  },
  
  getDraftPayload: async ({ user, ticketId }) => {
    const tenantId = tenantIdOf(user);
    if (!ticketId) fail('Thiếu Ticket ID.', 400, 'MFO_TICKET_REQUIRED');

    // AMEND-02 V1.2: Lọc tenant_id trực tiếp để trả về 404 (chống dò UUID)
    const where = { id: ticketId, deleted_at: null };
    if (tenantId) where.tenant_id = tenantId;
    const proposal = await prisma.proposals.findFirst({ where });

    if (!proposal) {
      fail('Không tìm thấy bản ghi Tờ trình / Bản nháp.', 404, 'MFO_LOT_NOT_FOUND');
    }

    const payload = proposal.payload || {};
    let targetMemberGeneration = null;
    const targetMemberId = proposal.target_id || payload.target_member_id || payload.origin_member_id;
    if (targetMemberId) {
      const targetMemberWhere = { id: targetMemberId, deleted_at: null };
      if (tenantId) targetMemberWhere.tenant_id = tenantId;
      const targetMember = await prisma.members.findFirst({
        where: targetMemberWhere,
        select: { generation: true },
      });
      targetMemberGeneration = targetMember?.generation ?? null;
    }

    return {
      ticket_id: proposal.id,
      tenant_id: proposal.tenant_id,
      target_member_id: proposal.target_id,
      target_member_generation: targetMemberGeneration,
      status: proposal.status,
      ticket_type: proposal.ticket_type,
      updated_at: proposal.updated_at,
      expires_at: proposal.expires_at,
      admin_note: proposal.admin_note || payload.admin_note || payload.reject_reason || null,

      selected_canvas_depth: payload.selected_canvas_depth ?? payload.k ?? 0,
      lines: payload.lines || [],
      
      canvas_delta: payload.canvas_delta || {
        draft_children: [],
        draft_spouses: [],
        node_positions_x: {},
      },
      smp_staging_data: payload.smp_staging_data || {},
      graph_snapshot: payload.graph_snapshot || null,
      init_scs: payload.init_scs || payload.diff_summary || null,
      diff_summary: payload.diff_summary || payload.init_scs || null,
      review_scs: payload.review_scs || null,
      submission_history: payload.submission_history || [],
      review_rounds: payload.review_rounds || [],
      current_attempt: payload.current_attempt || 1,

      plan_ok: Boolean(payload.plan_ok),
      result_submitted: Boolean(payload.result_submitted),
      result_ok: Boolean(payload.result_ok),
      granted_generation: payload.granted_generation ?? null,
      granted_branch_id: payload.granted_branch_id ?? null,
    };
  },

  deleteDraft: async ({ user, ticketId }) => {
    const actor = actorIdOf(user);
    if (!actor) fail('Thiếu người thực hiện.', 401, 'UNAUTHENTICATED');
    const tenantId = tenantIdOf(user);
    if (!tenantId) fail('Thiếu tenant.', 400, 'TENANT_REQUIRED');

    // AMEND-02 V1.2: Ràng buộc tenant_id trực tiếp để trả về 404 (chống dò UUID)
    const proposal = await prisma.proposals.findFirst({
      where: {
        id: ticketId,
        tenant_id: tenantId,
        deleted_at: null,
      },
    });

    if (!proposal) {
      fail('Không tìm thấy bản nháp/tờ trình cần xóa.', 404, 'MFO_DRAFT_NOT_FOUND');
    }

    const status = String(proposal.status).toUpperCase();
    const payload = proposal.payload || {};

    const isDraft = status === 'DRAFT';
    const isNeedsRevision = status === 'NEEDS_REVISION';
    const isGate1ApprovedOnly = status === 'APPROVED' && payload.plan_ok === true && !payload.result_submitted && !payload.result_ok;

    if (!isDraft && !isNeedsRevision && !isGate1ApprovedOnly) {
      fail(
        `Tờ trình đang ở trạng thái [${status}]. Không thể xóa hồ sơ đang trong luồng thẩm định, đã chốt sổ thật hoặc đã bị bác bỏ!`,
        409,
        'MFO_NOT_DELETABLE_STATE'
      );
    }

    if (!isClanOrSys(user) && String(proposal.requester_user_id) !== String(actor)) {
      fail('Không có quyền xóa bản nháp/tờ trình này.', 403, 'FORBIDDEN');
    }

    const now = new Date();
    /* *****************************
    return await withTransaction(
      { tenantId, actorId: actor, correlationId: proposal.correlation_id },
      async (tx) => {
        // AMEND-02 V1.2: updateMany có tenant_id + deleted_at bảo đảm cách ly tuyệt đối
        await tx.proposals.updateMany({
          where: { id: ticketId, tenant_id: tenantId, deleted_at: null },
          data: {
            deleted_at: now,
            hold_member_ids: [],
            changed_by: actor,
          },
        });
        const updated = await tx.proposals.findFirst({
          where: { id: ticketId, tenant_id: tenantId },
        });

        await mfoWriteBpl(tx, {
          processType: 'MFO_PLAN_SUBMIT',
          user,
          ticket: updated,
          payload: {
            action: 'MFO_DRAFT_DELETED',
            ticket_id: updated.id,
            target_member_id: updated.target_id,
            deleted_from_status: proposal.status,
            deleted_at: now.toISOString(),
            deleted_by: actor,
          },
        });

        await audit.create(tx, {
          tableName: 'proposals',
          recordId: updated.id,
          action: 'XOA',
          tenantId,
          changedBy: actor,
          correlationId: proposal.correlation_id,
          oldData: {
            id: proposal.id,
            status: proposal.status,
            target_id: proposal.target_id,
            deleted_at: null,
          },
          newData: {
            id: updated.id,
            status: updated.status,
            target_id: updated.target_id,
            deleted_at: now.toISOString(),
          },
          changeReason: `Người dùng xóa tờ trình ở trạng thái [${proposal.status}] theo quy chuẩn EU Delete Matrix`,
        });

        return { id: updated.id, deleted: true, deleted_at: updated.deleted_at };
      }
    );
    ***************************** */

    return await withTransaction(
      { tenantId, actorId: actor, correlationId: proposal.correlation_id },
      async (tx) => {
        await tx.proposals.updateMany({
          where: { id: ticketId, tenant_id: tenantId, deleted_at: null },
          data: {
            deleted_at: now,
            hold_member_ids: [],
            changed_by: actor,
          },
        });

        await mfoWriteBpl(tx, {
          processType: 'MFO_PLAN_SUBMIT',
          user,
          ticket: proposal,
          payload: {
            action: 'MFO_DRAFT_DELETED',
            ticket_id: proposal.id,
            target_member_id: proposal.target_id,
            deleted_from_status: proposal.status,
            deleted_at: now.toISOString(),
            deleted_by: actor,
          },
        });

        if (audit && typeof audit.create === 'function') {
          await audit.create(tx, {
            tableName: 'proposals',
            recordId: proposal.id,
            action: 'XOA',
            tenantId,
            changedBy: actor,
            correlationId: proposal.correlation_id,
            oldData: {
              id: proposal.id,
              status: proposal.status,
              target_id: proposal.target_id,
              deleted_at: null,
            },
            newData: {
              id: proposal.id,
              status: proposal.status,
              target_id: proposal.target_id,
              deleted_at: now.toISOString(),
            },
            changeReason: `Người dùng xóa tờ trình ở trạng thái [${proposal.status}] theo quy chuẩn EU Delete Matrix`,
          });
        }

        return { id: proposal.id, deleted: true, deleted_at: now };
      }
    );
  },

  createPlan: async ({ user, body, correlationId }) => {
    const actor = actorIdOf(user);
    if (!actor) fail('Thiếu người thực hiện.', 401, 'UNAUTHENTICATED');
    const tenantId = tenantIdOf(user);
    if (!tenantId) fail('Thiếu tenant.', 400, 'TENANT_REQUIRED');

    const founderMemberId = await resolveFounderMemberId(user);
    if (!founderMemberId && !isClanOrSys(user)) {
      fail(
        'Founder phải là MWL (users.member_id). ADMIN IT được kê hộ.',
        422,
        'MFO_FOUNDER_NOT_MWL'
      );
    }

    const payload = normalizePlanBody(body);
    const corr = correlationId || crypto.randomUUID();

    // AMEND-02 V1.2: Ràng buộc tenant_id trực tiếp để trả về 404 (chống dò UUID)
    const origin = await prisma.members.findFirst({
      where: { id: payload.origin_member_id, tenant_id: tenantId, deleted_at: null },
    });
    if (!origin) {
      fail('Không tìm thấy Origin trên sổ.', 404, 'MFO_ORIGIN_NOT_FOUND');
    }

    payload.founder_user_id = actor;
    payload.founder_member_id = founderMemberId || null;

    const ticket = await withTransaction(
      { tenantId, actorId: actor, correlationId: corr },
      async (tx) => {
        const ticketIdFromBody = body.ticket_id || body.ticketId;
        
        await ensureNoActiveProposal(tx, { 
          tenantId, 
          actorId: actor, 
          excludeId: ticketIdFromBody || null 
        });

        let existing = null;
        if (ticketIdFromBody) {
          existing = await tx.proposals.findFirst({
            where: { id: ticketIdFromBody, tenant_id: tenantId, deleted_at: null },
          });
          if (!existing) {
            fail('Không tìm thấy bản nháp Tờ trình.', 404, 'MFO_DRAFT_NOT_FOUND');
          }
          if (existing.status !== 'DRAFT' && existing.status !== 'NEEDS_REVISION') {
            fail(`Không thể trình khung từ trạng thái ${existing.status}.`, 409, 'MFO_PLAN_STATE', {
              ticket_status: existing.status,
            });
          }
        }

        const existingPayload = (existing && existing.payload) || {};
        const mergedPayload = {
          ...existingPayload,
          ...payload,
          target_member_id: body.target_member_id || existingPayload.target_member_id || payload.origin_member_id,
          origin_member_id: payload.origin_member_id || existingPayload.origin_member_id,
          selected_canvas_depth: payload.k,
          canvas_delta: body.canvas_delta || existingPayload.canvas_delta || {
            draft_children: [],
            draft_spouses: [],
            node_positions_x: {},
          },
          smp_staging_data: body.smp_staging_data || existingPayload.smp_staging_data || {},
          graph_snapshot: body.graph_snapshot || existingPayload.graph_snapshot || null,
          hold_member_ids: body.hold_member_ids || existingPayload.hold_member_ids || [],
          init_scs: body.init_scs || body.diff_summary || existingPayload.init_scs || null,
          diff_summary: body.diff_summary || body.init_scs || existingPayload.diff_summary || null,
          review_scs: null,
          review_rounds: existingPayload.review_rounds || [],
          current_attempt:
            existing?.status === 'NEEDS_REVISION'
              ? (Number(existingPayload.current_attempt) || 1) + 1
              : Number(existingPayload.current_attempt) || 1,
          kind: 'PLAN',
          plan_ok: false,
          result_submitted: false,
          result_ok: false,
        };
        const holdMemberIds = collectHoldMemberIds(mergedPayload);
        const submitConflict = await findHoldConflict(tx, {
          tenantId,
          memberIds: holdMemberIds,
          excludeProposalId: existing && existing.id,
          excludeRequesterId: actor,
        });
        if (submitConflict) {
          fail(
            'MFO_HOLD_CONFLICT',
            409,
            'MFO_HOLD_CONFLICT',
            { expires_at: submitConflict.expires_at || null }
          );
        }
        if (existing && existing.expires_at && new Date(existing.expires_at).getTime() <= Date.now()) {
          fail('Tờ đã hết hạn, không thể trình.', 409, 'MFO_HOLD_EXPIRED');
        }

        let row;
        if (ticketIdFromBody) {
          // AMEND-02 V1.2: updateMany có tenant_id + deleted_at bảo đảm cách ly tuyệt đối
          await tx.proposals.updateMany({
            where: { id: ticketIdFromBody, tenant_id: tenantId, deleted_at: null },
            data: {
              payload: mergedPayload,
              hold_member_ids: holdMemberIds,
              target_id: mergedPayload.origin_member_id,
              updated_at: new Date(),
              changed_by: actor,
            },
          });
          row = await tx.proposals.findFirst({
            where: { id: ticketIdFromBody, tenant_id: tenantId, deleted_at: null },
          });

          if (audit && typeof audit.create === 'function') {
            await audit.create(tx, {
              tableName: 'proposals',
              recordId: row.id,
              action: 'CAP_NHAT',
              tenantId,
              changedBy: actor,
              correlationId: corr,
              oldData: {
                target_id: existing.target_id,
                status: existing.status,
              },
              newData: {
                target_id: row.target_id,
                status: row.status,
              },
              changeReason: `Cập nhật nội dung trình khung MFO #${row.id}`,
            });
          }
        } else {
          row = await tx.proposals.create({
            data: {
              tenant_id: tenantId,
              ticket_type: 'MFO_REVIEW',
              status: 'DRAFT',
              requester_user_id: actor,
              target_table: 'members',
              target_id: mergedPayload.origin_member_id,
              payload: mergedPayload,
              hold_member_ids: holdMemberIds,
              expires_at: expiresAtFor('DRAFT', new Date()),
              payload_schema_version: 2,
              correlation_id: corr,
              changed_by: actor,
            },
          });

          if (audit && typeof audit.create === 'function') {
            await audit.create(tx, {
              tableName: 'proposals',
              recordId: row.id,
              action: 'THEM_MOI',
              tenantId,
              changedBy: actor,
              correlationId: corr,
              oldData: null,
              newData: {
                id: row.id,
                target_id: row.target_id,
                status: row.status,
              },
              changeReason: `Tạo tờ trình MFO 5L neo tại mốc ${mergedPayload.origin_member_id}`,
            });
          }
        }

        return row;
      }
    );

    return { ticket, payload };
  },

  canCreate: async ({ user }) => {
    const actor = actorIdOf(user);
    const tenantId = tenantIdOf(user);
    if (!actor || !tenantId) fail('Thiếu người thực hiện.', 401, 'UNAUTHENTICATED');
    const active = await prisma.proposals.findFirst({
      where: {
        tenant_id: tenantId,
        requester_user_id: actor,
        ticket_type: { in: ['MFO_REVIEW', 'BRANCH_REVIEW'] },
        deleted_at: null,
        OR: [
          { status: { in: OPEN } },
          { status: 'APPROVED', payload: { path: ['result_ok'], equals: false } },
        ],
      },
      select: { id: true, status: true, expires_at: true },
    });
    if (active) {
      fail('Bác đang có một tờ chưa xong. Hãy làm xong tờ cũ trước khi mở tờ mới.', 409, 'MFO_ACTIVE_PROPOSAL_EXISTS', {
        active_ticket_id: active.id,
        status: active.status,
        expires_at: active.expires_at || null,
      });
    }
    return { ok: true };
  },

  listPlans: async ({ user, query }) => {
    const started = Date.now();
    const tenantId = tenantIdOf(user);
    if (!tenantId) fail('Thiếu tenant.', 400, 'TENANT_REQUIRED');
    const q = query || {};
    const actorId = actorIdOf(user);
    const isClanAdmin = isClanOrSys(user);

    const limit = Math.min(Number(q.limit) || 50, 100);

    let filterRequesterId = null;
    if (!isClanAdmin || q.mine === '1' || q.mine === 'true') {
      filterRequesterId = actorId;
    }

    const originId = q.origin_id ? String(q.origin_id).trim() : null;

    let filterStatus = null;
    let filterPlanOk = null;
    let filterResultSubmitted = null;
    let filterResultOk = null;

    if (q.status && q.status !== 'ALL' && q.status !== 'BAM_DE_CHON') {
      switch (q.status) {
        case 'C1_DRAFT':
        case 'DRAFT':
          filterStatus = 'DRAFT';
          filterPlanOk = false;
          break;

        case 'C1_PENDING':
        case 'PENDING':
          filterStatus = 'PENDING';
          break;

        case 'C1_NEEDS_REVISION':
          filterStatus = 'NEEDS_REVISION';
          filterPlanOk = false;
          break;

        case 'C1_APPROVED':
        case 'C2_DRAFT':
          filterStatus = 'APPROVED';
          filterPlanOk = true;
          filterResultSubmitted = false;
          break;

        case 'C1_REJECTED':
          filterStatus = 'REJECTED';
          filterPlanOk = false;
          break;

        case 'C2_PENDING':
        case 'UNDER_REVIEW':
          filterStatus = 'UNDER_REVIEW';
          filterPlanOk = true;
          break;

        case 'C2_NEEDS_REVISION':
          filterStatus = 'NEEDS_REVISION';
          filterPlanOk = true;
          break;

        case 'C2_REJECTED':
          filterStatus = 'REJECTED';
          filterPlanOk = true;
          break;

        case 'RECORDED':
          filterStatus = 'APPROVED';
          filterResultOk = true;
          break;

        default:
          filterStatus = q.status;
          break;
      }
    }

    const rows = await prisma.$queryRaw`
      SELECT 
        p.id,
        p.status::text AS status,
        p.requester_user_id,
        p.target_id,
        p.correlation_id,
        p.created_at,
        p.updated_at,
        p.reviewed_at,
        p.admin_note,
        COALESCE((p.payload->>'plan_ok')::boolean, false) AS plan_ok,
        COALESCE((p.payload->>'result_ok')::boolean, false) AS result_ok,
        COALESCE((p.payload->>'result_submitted')::boolean, false) AS result_submitted,
        COALESCE((p.payload->>'k')::int, (p.payload->>'selected_canvas_depth')::int, 0) AS k,
        (p.payload->>'granted_generation')::int AS granted_generation,
        (p.payload ? 'canvas_delta' AND p.payload->'canvas_delta' IS NOT NULL) AS has_delta,
        (p.payload ? 'graph_snapshot' AND p.payload->'graph_snapshot' IS NOT NULL) AS has_snapshot,
        COALESCE((p.payload->>'current_attempt')::int, 1) AS current_attempt,
        p.payload->>'note' AS payload_note
      FROM proposals p
      WHERE p.deleted_at IS NULL
        AND p.tenant_id = ${tenantId}
        AND p.ticket_type IN ('MFO_REVIEW', 'BRANCH_REVIEW')
        AND (${filterRequesterId}::text IS NULL OR p.requester_user_id = ${filterRequesterId})
        AND (${originId}::text IS NULL OR p.target_id = ${originId})
        AND (${filterStatus}::text IS NULL OR p.status::text = ${filterStatus})
        AND (${filterPlanOk}::boolean IS NULL OR COALESCE((p.payload->>'plan_ok')::boolean, false) = ${filterPlanOk})
        AND (${filterResultSubmitted}::boolean IS NULL OR COALESCE((p.payload->>'result_submitted')::boolean, false) = ${filterResultSubmitted})
        AND (${filterResultOk}::boolean IS NULL OR COALESCE((p.payload->>'result_ok')::boolean, false) = ${filterResultOk})
      ORDER BY p.updated_at DESC
      LIMIT ${limit}
    `;

    const mapped = (rows || []).map((r) => ({
      id: r.id,
      ticket_id: r.id,
      status: r.status,
      is_draft: r.status === 'DRAFT',
      plan_ok: Boolean(r.plan_ok),
      result_ok: Boolean(r.result_ok),
      result_submitted: Boolean(r.result_submitted),
      admin_review: null,
      kind: 'PLAN',
      target_member_id: r.target_id,
      origin_member_id: r.target_id,
      selected_canvas_depth: r.k ?? 0,
      k: r.k ?? 0,
      granted_generation: r.granted_generation,
      requester_user_id: r.requester_user_id,
      correlation_id: r.correlation_id,
      created_at: r.created_at,
      updated_at: r.updated_at,
      reviewed_at: r.reviewed_at,
      note: r.payload_note || r.admin_note || null,
      admin_note: r.admin_note || null,
      has_delta: Boolean(r.has_delta),
      has_snapshot: Boolean(r.has_snapshot),
      init_scs: null,
      diff_summary: null,
      review_scs: null,
      review_rounds: [],
      current_attempt: r.current_attempt || 1,
    }));

    console.info('[LIST_PLANS_TIMING]', {
      count: mapped.length,
      service_ms: Date.now() - started,
    });

    return mapped;
  },

  getPlan: async ({ user, ticketId }) => {
    const tenantId = tenantIdOf(user);
    // AMEND-02 V1.2: Ràng buộc tenant_id trực tiếp để trả về 404 (chống dò UUID)
    const where = { id: ticketId, deleted_at: null };
    if (tenantId) where.tenant_id = tenantId;
    const row = await prisma.proposals.findFirst({
      where,
    });
    if (!row) fail('Không tìm thấy lô.', 404, 'MFO_LOT_NOT_FOUND');
    return { ticket: row, tree: null };
  },

  assertLot: async ({ user, ticketId, expectKind }) => {
    const got = await mfoService.getPlan({ user, ticketId });
    const row = got.ticket || got;
    return row;
  },

  approvePlan: async ({ user, ticketId, body }) => {
    if (!isClanOrSys(user)) {
      fail('Chỉ CLAN_ADMIN / SYSTEM_ADMIN phê PLAN.', 403, 'FORBIDDEN');
    }
    const row = await mfoService.assertLot({
      user,
      ticketId,
      expectKind: 'PLAN',
    });

    const b = body || {};
    const genRaw = b.granted_generation != null ? b.granted_generation : b.generation;
    const grantedGeneration = Number(genRaw);
    if (!Number.isFinite(grantedGeneration)) {
      fail('Phê PLAN bắt buộc granted_generation.', 422, 'MFO_GENERATION_REQUIRED');
    }

    const grantedBranchId =
      b.granted_branch_id === undefined
        ? row.payload.proposed_branch_id || null
        : b.granted_branch_id || null;

    const nextPayload = {
      ...row.payload,
      kind: 'PLAN',
      plan_ok: true,
      granted_generation: grantedGeneration,
      granted_branch_id: grantedBranchId,
      approver_note: b.note || b.admin_note || null,
      admin_review: pickAdminReview(b, row, 'plan'),
      review_scs: b.review_scs || row.payload.review_scs || null,
    };

    return { ticket: { ...row, payload: nextPayload }, plan_ok: true };
  },

  rejectPlan: async ({ user, ticketId, body }) => {
    if (!isClanOrSys(user)) {
      fail('Chỉ CLAN_ADMIN / SYSTEM_ADMIN từ chối PLAN.', 403, 'FORBIDDEN');
    }
    const row = await mfoService.assertLot({
      user,
      ticketId,
      expectKind: 'PLAN',
    });

    const reason = (body && (body.reason || body.note || body.admin_note)) || '';
    if (!String(reason).trim()) {
      fail('Từ chối PLAN bắt buộc reason.', 400, 'MFO_REASON_REQUIRED');
    }

    return { ticket: row, reason: String(reason).trim() };
  },

  returnPlanForRevision: async ({ user, ticketId, body }) => {
    const started = Date.now();
    if (!isClanOrSys(user)) {
      fail('Chỉ CLAN_ADMIN / SYSTEM_ADMIN có quyền yêu cầu sửa đổi.', 403, 'FORBIDDEN');
    }
    const actor = actorIdOf(user);
    const row = await mfoService.assertLot({
      user,
      ticketId,
      expectKind: 'PLAN',
    });

    if (row.status !== 'PENDING' && row.status !== 'UNDER_REVIEW') {
      fail('Chỉ trả hồ sơ đang ở trạng thái PENDING hoặc UNDER_REVIEW.', 409, 'MFO_PLAN_STATE', {
        ticket_status: row.status,
      });
    }

    const b = body || {};
    const reviewScs = b.review_scs || [];
    const globalAdminNote = String(b.note || b.admin_note || body.reason || '').trim();

    const previousRounds = Array.isArray(row.payload?.review_rounds)
      ? [...row.payload.review_rounds]
      : [];

    const closedRound = {
      attempt_no: Number(row.payload?.current_attempt) || 1,
      submitted_at: row.updated_at || row.created_at,
      requester_user_id: row.requester_user_id,
      init_scs: row.payload?.init_scs || row.payload?.diff_summary || [],
      reviewed_at: new Date().toISOString(),
      reviewer_user_id: actor,
      review_scs: reviewScs,
      global_admin_note: globalAdminNote || null,
      outcome: 'NEEDS_REVISION',
    };

    previousRounds.push(closedRound);

    const nextPayload = {
      ...row.payload,
      plan_ok: false,
      review_scs: reviewScs,
      review_rounds: previousRounds,
      admin_note: globalAdminNote || null,
      reject_reason: globalAdminNote || 'Yêu cầu hiệu chỉnh theo bút phê',
    };

    console.info('[MFO_RETURN_TIMING]', { service_ms: Date.now() - started });
    return { ticket: { ...row, payload: nextPayload }, reviewScs, globalAdminNote };
  },

  getOriginTree: async ({ user, originId }) => {
    const tenantId = tenantIdOf(user);
    if (!originId) fail('Thiếu origin id.', 400, 'MFO_ORIGIN_REQUIRED');

    // AMEND-02 V1.2: Ràng buộc tenant_id trực tiếp để trả về 404 (chống dò UUID)
    const originWhere = { id: originId, deleted_at: null };
    if (tenantId) originWhere.tenant_id = tenantId;
    const origin = await prisma.members.findFirst({
      where: originWhere,
      select: {
        id: true,
        full_name: true,
        generation: true,
        gender: true,
        father_id: true,
        mother_id: true,
        tenant_id: true,
        deleted_at: true,
        branch_id: true,
        is_clan: true,
        child_type: true,
      },
    });
    if (!origin) {
      fail('Không tìm thấy Origin trên sổ.', 404, 'MFO_ORIGIN_NOT_FOUND');
    }

    const all = await prisma.members.findMany({
      where: { tenant_id: origin.tenant_id, deleted_at: null },
      select: {
        id: true,
        full_name: true,
        generation: true,
        gender: true,
        father_id: true,
        mother_id: true,
        branch_id: true,
        is_clan: true,
        child_type: true,
        sibling_seq: true,
        birth_year: true,
        note: true,
      },
    });

    const unions = await prisma.marriages.findMany({
      where: {
        tenant_id: origin.tenant_id,
        deleted_at: null,
        status: { in: ['DANG_KET_HON', 'GOA'] },
      },
      select: {
        id: true,
        husband_id: true,
        wife_id: true,
        husband_marriage_order: true,
        wife_marriage_order: true,
        status: true,
        spouse_name_literal: true,
      },
    });

    const isNoi = (m) => !m || m.is_clan !== false;

    const byId = new Map(all.map((m) => [m.id, m]));
    const noiOf = new Map();
    for (const m of all) {
      if (!isNoi(m)) continue;
      for (const pid of [m.father_id, m.mother_id]) {
        if (!pid) continue;
        if (!noiOf.has(pid)) noiOf.set(pid, []);
        if (!noiOf.get(pid).includes(m.id)) noiOf.get(pid).push(m.id);
      }
    }

    const partnersOf = new Map();
    const pushPartner = (ownerId, partner, meta) => {
      if (!ownerId || !partner) return;
      if (partner.id && partner.id === ownerId) return;
      if (!partnersOf.has(ownerId)) partnersOf.set(ownerId, []);
      const bag = partnersOf.get(ownerId);
      const key = partner.id || 'lit:' + (partner.full_name || '');
      if (bag.some((p) => p._key === key)) return;
      bag.push({ ...partner, _key: key, _ord: meta.ord || 99, _status: meta.status });
    };
    for (const u of unions) {
      const hus = u.husband_id && byId.get(u.husband_id);
      const wif = u.wife_id && byId.get(u.wife_id);
      if (u.husband_id && wif) {
        pushPartner(u.husband_id, wif, {
          ord: u.husband_marriage_order,
          status: u.status,
        });
      } else if (u.husband_id && u.spouse_name_literal) {
        pushPartner(u.husband_id, { id: null, full_name: u.spouse_name_literal }, {
          ord: u.husband_marriage_order,
          status: u.status,
        });
      }
      if (u.wife_id && hus) {
        pushPartner(u.wife_id, hus, {
          ord: u.wife_marriage_order,
          status: u.status,
        });
      } else if (u.wife_id && !hus && u.spouse_name_literal) {
        pushPartner(u.wife_id, { id: null, full_name: u.spouse_name_literal }, {
          ord: u.wife_marriage_order,
          status: u.status,
        });
      }
    }

    const pack = (m, extra) => ({
      id: m.id || null,
      full_name: m.full_name,
      is_unknown: !!(
        (m.note && String(m.note).includes('[UM]')) ||
        (m.full_name && /^chưa rõ/i.test(String(m.full_name)))
      ),
      generation: m.generation != null ? m.generation : null,
      gender: m.gender || null,
      father_id: m.father_id || null,
      mother_id: m.mother_id || null,
      branch_id: m.branch_id || null,
      is_clan: m.is_clan !== false,
      child_type: m.child_type || null,
      sibling_seq: m.sibling_seq != null ? m.sibling_seq : null,
      ...extra,
    });

    const sibSort = (ids) =>
      ids
        .map((id) => byId.get(id))
        .filter(Boolean)
        .sort((a, b) => {
          const sa = a.sibling_seq == null ? 9999 : a.sibling_seq;
          const sb = b.sibling_seq == null ? 9999 : b.sibling_seq;
          if (sa !== sb) return sa - sb;
          const ya = a.birth_year == null ? 9999 : a.birth_year;
          const yb = b.birth_year == null ? 9999 : b.birth_year;
          if (ya !== yb) return ya - yb;
          return String(a.full_name || '').localeCompare(String(b.full_name || ''), 'vi');
        })
        .map((m) => m.id);

    const MAX_DEPTH = 4;
    const nodes = [];
    const seen = new Set();
    const queue = [{ id: origin.id, depth: 0 }];
    seen.add(origin.id);
    while (queue.length) {
      const cur = queue.shift();
      const m = byId.get(cur.id);
      if (!m) continue;
      const partners = (partnersOf.get(cur.id) || [])
        .sort((a, b) => (a._ord || 99) - (b._ord || 99))
        .map((p) =>
          pack(p, {
            depth: cur.depth,
            role: 'partner',
            source: p.id ? 'marriage' : 'literal',
            union_status: p._status || null,
          })
        );
      nodes.push(
        pack(m, {
          depth: cur.depth,
          is_origin: cur.depth === 0,
          partners,
        })
      );
      if (cur.depth >= MAX_DEPTH) continue;
      for (const kid of sibSort(noiOf.get(cur.id) || [])) {
        if (seen.has(kid)) continue;
        seen.add(kid);
        queue.push({ id: kid, depth: cur.depth + 1 });
      }
    }

    const mwlId = await resolveFounderMemberId(user);
    let k = null;
    let k_reason = 'no_mwl';
    const path = [];
    if (mwlId) {
      const mwl = byId.get(mwlId);
      if (mwl && mwl.is_clan === false) {
        k_reason = 'ngoai_toc';
      } else if (mwlId === origin.id) {
        k = 0;
        k_reason = 'self';
        path.push(origin.id);
      } else {
        const vis = new Set();
        const q = [{ id: mwlId, steps: 0, trail: [mwlId] }];
        vis.add(mwlId);
        let hit = null;
        while (q.length && !hit) {
          const cur = q.shift();
          if (cur.steps > 32) continue;
          if (cur.id === origin.id) {
            hit = cur;
            break;
          }
          const row = byId.get(cur.id);
          if (!row) continue;
          for (const pid of [row.father_id, row.mother_id]) {
            if (!pid || vis.has(pid)) continue;
            const parent = byId.get(pid);
            if (parent && parent.is_clan === false) continue;
            vis.add(pid);
            q.push({
              id: pid,
              steps: cur.steps + 1,
              trail: [pid, ...cur.trail],
            });
          }
        }
        if (hit) {
          k = hit.steps;
          k_reason = k > 4 ? 'too_far' : 'on_tree';
          path.push(...hit.trail);
        } else {
          k = null;
          k_reason = 'not_on_tree';
        }
      }
    }

    return {
      origin: {
        id: origin.id,
        full_name: origin.full_name,
        generation: origin.generation,
        branch_id: origin.branch_id,
        is_clan: origin.is_clan !== false,
      },
      window_depth: MAX_DEPTH,
      rule: 'is_clan+marriages',
      nodes,
      mwl: {
        member_id: mwlId,
        k,
        k_reason,
        in_window: k !== null && k <= 4,
        path_to_origin: path,
      },
    };
  },

  saveStaging: async ({ user, ticketId, body }) => {
    const actor = actorIdOf(user);
    const tenantId = tenantIdOf(user);
    if (!actor) fail('Thiếu người thực hiện.', 401, 'UNAUTHENTICATED');
    if (!tenantId) fail('Thiếu tenant.', 400, 'TENANT_REQUIRED');

    const row = await mfoService.assertLot({
      user,
      ticketId,
      expectKind: 'PLAN',
    });
    if (!isClanOrSys(user) && String(row.requester_user_id) !== String(actor)) {
      fail('Chỉ người trình được lưu tờ khai.', 403, 'FORBIDDEN');
    }
    const payload = row.payload || {};
    if (!payload.plan_ok || payload.result_submitted || payload.result_ok) {
      fail('Xưởng chưa mở hoặc tờ khai đã đóng.', 409, 'MFO_GATE2_CLOSED');
    }
    const delta = payload.canvas_delta || {};
    const incoming = normalizeStaging(body && body.smp_staging_data, delta);
    const nextPayload = {
      ...payload,
      smp_staging_data: {
        ...(payload.smp_staging_data || {}),
        ...incoming,
      },
    };

    const corr = row.correlation_id || crypto.randomUUID();

    const ticket = await withTransaction(
      { tenantId, actorId: actor, correlationId: corr },
      async (tx) => {
        // AMEND-02 V1.2: updateMany có tenant_id + deleted_at bảo đảm cách ly tuyệt đối
        await tx.proposals.updateMany({
          where: { id: row.id, tenant_id: tenantId, deleted_at: null },
          data: {
            payload: nextPayload,
            updated_at: new Date(),
            changed_by: actor,
          },
        });
        const updated = await tx.proposals.findFirst({
          where: { id: row.id, tenant_id: tenantId, deleted_at: null },
        });

        if (audit && typeof audit.create === 'function') {
          await audit.create(tx, {
            tableName: 'proposals',
            recordId: updated.id,
            action: 'CAP_NHAT',
            tenantId,
            changedBy: actor,
            correlationId: corr,
            oldData: {
              staging_keys_count: Object.keys(payload.smp_staging_data || {}).length,
            },
            newData: {
              staging_keys_count: Object.keys(nextPayload.smp_staging_data || {}).length,
            },
            changeReason: `Cập nhật dữ liệu nhân khẩu SMP tại xưởng Workbench #${updated.id}`,
          });
        }

        return updated;
      }
    );

    return { ticket, smp_staging_data: nextPayload.smp_staging_data };
  },

  submitResult: async ({ user, ticketId, body }) => {
    const actor = actorIdOf(user);
    const row = await mfoService.assertLot({
      user,
      ticketId,
      expectKind: 'PLAN',
    });
    if (!isClanOrSys(user) && String(row.requester_user_id) !== String(actor)) {
      fail('Chỉ người trình hoặc ADMIN nộp RESULT.', 403, 'FORBIDDEN');
    }
    if (!row.payload || !row.payload.plan_ok) {
      fail(
        'Chỉ nộp RESULT khi PLAN đã có tem phê duyệt plan_ok.',
        409,
        'MFO_PLAN_STATE',
        { ticket_status: row.status }
      );
    }
    if (row.payload.result_ok) {
      fail('RESULT đã nghiệm thu hoàn tất.', 409, 'MFO_RESULT_DONE');
    }
    assertClanConfirmed(row.payload);

    return { ticket: row };
  },

  approveResult: async ({ user, ticketId, body }) => {
    if (!isClanOrSys(user)) {
      fail('Chỉ ADMIN nghiệm thu RESULT.', 403, 'FORBIDDEN');
    }
    const row = await mfoService.assertLot({
      user,
      ticketId,
      expectKind: 'PLAN',
    });

    if (!row.payload || !row.payload.result_submitted) {
      fail('Chưa nộp Tờ khai Nghiệm thu kết quả xưởng.', 409, 'MFO_RESULT_NOT_SUBMITTED');
    }
    assertClanConfirmed(row.payload);

    return { ticket: row };
  },

  rejectResult: async ({ user, ticketId, body }) => {
    if (!isClanOrSys(user)) {
      fail('Chỉ ADMIN trả RESULT.', 403, 'FORBIDDEN');
    }
    const row = await mfoService.assertLot({
      user,
      ticketId,
      expectKind: 'PLAN',
    });
    if (row.status === 'APPROVED' && row.payload && row.payload.result_ok) {
      fail('Tờ khai đã nghiệm thu chốt Sổ thật, không thể trả lại.', 409, 'MFO_RESULT_DONE');
    }
    const reason = (body && (body.reason || body.note || body.admin_note)) || '';
    if (!String(reason).trim()) {
      fail('Trả lại Tờ khai bắt buộc phải có bút phê lý do.', 400, 'MFO_REASON_REQUIRED');
    }

    return { ticket: row, reason: String(reason).trim() };
  },

  terminateResult: async ({ user, ticketId, body }) => {
    if (!isClanOrSys(user)) {
      fail('Chỉ ADMIN bác bỏ tờ khai.', 403, 'FORBIDDEN');
    }
    const row = await mfoService.assertLot({
      user,
      ticketId,
      expectKind: 'PLAN',
    });
    if (!row.payload || !row.payload.plan_ok) {
      fail('Chưa có khung đã duyệt.', 409, 'MFO_PLAN_STATE');
    }
    if (row.payload.result_ok) {
      fail('Tờ khai đã ghi sổ, không bác bỏ.', 409, 'MFO_RESULT_DONE');
    }
    const reason = (body && (body.reason || body.note || body.admin_note)) || '';
    if (!String(reason).trim()) {
      fail('Bác bỏ tờ khai bắt buộc có ý kiến.', 400, 'MFO_REASON_REQUIRED');
    }
    return { ticket: row, reason: String(reason).trim() };
  },

  abortPlan: async ({ user, ticketId, body }) => {
    const actor = actorIdOf(user);
    const tenantId = tenantIdOf(user);
    if (!actor) fail('Thiếu người thực hiện.', 401, 'UNAUTHENTICATED');
    if (!tenantId) fail('Thiếu tenant.', 400, 'TENANT_REQUIRED');

    const row = await mfoService.assertLot({
      user,
      ticketId,
      expectKind: 'PLAN',
    });
    if (!isClanOrSys(user) && String(row.requester_user_id) !== String(actor)) {
      fail('Không có quyền rút tờ trình này.', 403, 'FORBIDDEN');
    }
    if (row.payload && row.payload.result_ok) {
      fail('Tờ trình đã chốt Sổ họ, không thể rút.', 409, 'MFO_RESULT_DONE');
    }
    const st = String(row.status || '');
    const submitted = !!(row.payload && row.payload.result_submitted);
    const allowed =
      st === 'PENDING' ||
      st === 'NEEDS_REVISION' ||
      (st === 'APPROVED' && !submitted);
    if (!allowed) {
      fail('Không rút được tờ trình ở trạng thái này.', 409, 'MFO_PLAN_STATE', {
        ticket_status: row.status,
      });
    }

    const now = new Date();
    const nextPayload = {
      ...row.payload,
      aborted: true,
      aborted_at: now.toISOString(),
      aborted_by: actor,
      plan_ok: false,
      result_submitted: false,
      result_ok: false,
    };

    const corr = row.correlation_id || crypto.randomUUID();

    const ticket = await withTransaction(
      { tenantId, actorId: actor, correlationId: corr },
      async (tx) => {
        // AMEND-02 V1.2: updateMany có tenant_id + deleted_at bảo đảm cách ly tuyệt đối
        await tx.proposals.updateMany({
          where: { id: row.id, tenant_id: tenantId, deleted_at: null },
          data: {
            status: 'WITHDRAWN',
            payload: nextPayload,
            admin_note: (body && (body.note || body.reason)) || row.admin_note,
            changed_by: actor,
          },
        });
        const updated = await tx.proposals.findFirst({
          where: { id: row.id, tenant_id: tenantId },
        });

        if (audit && typeof audit.create === 'function') {
          await audit.create(tx, {
            tableName: 'proposals',
            recordId: updated.id,
            action: 'CAP_NHAT',
            tenantId,
            changedBy: actor,
            correlationId: corr,
            oldData: {
              status: row.status,
            },
            newData: {
              status: 'WITHDRAWN',
              aborted_at: now.toISOString(),
            },
            changeReason: `Người dùng rút tờ trình MFO #${updated.id}`,
          });
        }

        return updated;
      }
    );

    await afterMfo(user, ticket, 'MFO_PLAN_ABORT', 'MFO_PLAN_ABORTED', {
      from_status: row.status,
      to_status: 'WITHDRAWN',
    });
    return { ticket, aborted: true };
  },
};

function assertClanConfirmed(payload) {
  const root = payload || {};
  const layer = root.business_layer && typeof root.business_layer === 'object' ? root.business_layer : root;
  const staging = layer.smp_staging_data || root.smp_staging_data || {};
  const delta = layer.canvas_delta || root.canvas_delta || {};
  const people = [
    ...(delta.draft_children || []).map((row) => staging[row.id]),
    ...(delta.draft_spouses || []).map((row) => staging[row.union_id]),
  ];
  const missing = people.some((smp) => !smp || (smp.is_clan !== true && smp.is_clan !== false));
  if (missing) {
    fail('Chưa khẳng định nội tộc.', 422, 'MFO_CLAN_UNCONFIRMED');
  }
}

module.exports = mfoService;