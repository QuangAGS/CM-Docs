/**
 * PATH       : src/app.js
 * DATETIME   : 2026-11-22T23:10:00+07:00
 * VERSION    : 21.11.0-ISO29148-UAT-IMP6-SANDBOX
 * DESCRIPTION:
 * - [21.10.0-UAT-BUG5-CORS-FIX] Bổ sung X-Turnstile-Token và X-Correlation-Id
 *   vào allowedHeaders và exposedHeaders của cấu hình CORS để sửa lỗi UAT Bug 5
 *   (CORS error chặn preflight OPTIONS khi Frontend gửi custom headers).
 * - [21.9.0-MULTIHOME-AMEND02-V15-LAT3] Mount /api/membership (membership.routes) cho luồng C1 & C1-S.
 * - [21.8.0-MULTIHOME-AMEND02-V15-LAT1] Mount /api/public (publicSearch.routes) cho Guest Claim.
 * - [21.7.0-W2] Wave 2 PR-W2-3: Early tenant 404 → next(err) dual-contract CED.
 * - Production Hardening: Security Headers & CORS.
 * - Bảo tồn toàn bộ logic cũ (Q1, Q2, Q3, Q4).
 *
 * CHANGELOG:
 * - 21.8.0-MULTIHOME-AMEND02-V15-LAT1 (2026-11-12): Mount /api/public cho Guest Claim search.
 * - 21.9.0-MULTIHOME-AMEND02-V15-LAT3 (2026-11-13): Mount /api/membership cho Multi-Home C1 & C1-S.
 * - 21.10.0-UAT-BUG5-CORS-FIX (2026-11-20): Fix CORS allowedHeaders cho Turnstile và CorrelationId.
 */

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');

const { basePrisma, tenantContext } = require('./lib/prisma.js');

// === PRODUCTION HARDENING: VALIDATE ENV ===
const securityConfig = require('./config/securityConfig');

// === CED Kernel (Wave 0) ===
const { createGlobalErrorHandler } = require('./shared/errors');
const correlationMiddleware = require('./middlewares/correlation.middleware');

// IMPORT ROUTES & MIDDLEWARES
const branchRoutes = require('./modules/members/branch.routes');
const mfoRoutes = require('./modules/mfo/mfo.routes');
const memberRoutes = require('./modules/members/member.routes');
const addressRoutes = require('./modules/interactions/address.routes');
const worshipRoutes = require('./modules/worship/worship.routes');
const tenantRoutes = require('./modules/tenants/tenant.routes');
const authLogRoutes = require('./modules/auth/authLog.routes');
const notificationRoutes = require('./modules/notifications/notification.routes');
const { loginRateLimiter } = require('./middlewares/rateLimit.middleware');
const achievementRoutes = require('./modules/tenants/achievement.routes');
const assetRoutes = require('./modules/finance/asset.routes');
const cemeteryRoutes = require('./modules/worship/cemetery.routes');
const graveRoutes = require('./modules/worship/grave.routes');
const eventRoutes = require('./modules/interactions/event.routes');
const fundRoutes = require('./modules/finance/fund.routes');
const fundTransactionRoutes = require('./modules/finance/fundTransaction.routes');
const suggestionRoutes = require('./modules/interactions/suggestion.routes');
const mediaRoutes = require('./modules/interactions/media.routes');

// [21.5.2] Onboarding module (EGAL-25.x OPD v1.1.0)
const onboardingRoutes = require('./modules/onboarding/onboarding.routes');
const membershipRoutes = require('./modules/membership/membership.routes');
const profileRoutes = require('./modules/profile/profile.routes');

const publicSearchRoutes = require('./modules/public/publicSearch.routes');
const authRoutesRaw = require('./modules/auth/auth.routes');
const authRoutes = authRoutesRaw.default || authRoutesRaw;

const app = express();

// === SECURITY CONFIG - PRODUCTION READY ===
app.set('trust proxy', 1);

// ─────────────────────────────────────────────────────────────
// [21.6.0-W1] CORRELATION FIRST (CED E5 + Master Plan W1)
// Phải đứng trước mọi middleware khác để mọi response lỗi đều có correlationId.
// ─────────────────────────────────────────────────────────────
app.use(correlationMiddleware);

app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", "'unsafe-inline'"], // cần cho Turnstile
      },
    },
    hsts: {
      maxAge: 31536000,
      includeSubDomains: true,
      preload: true,
    },
    xFrameOptions: {
      action: 'deny',
    },
    hidePoweredBy: true,
  })
);

// CORS Production
app.use(
  cors({
    /**
     * <2026-05-13T00:00:00+07:00>
     * Config Gateway:
     * - ALLOWED_ORIGINS lấy từ .env qua securityConfig.
     * - Không hard-code domain tại app.js nữa.
     * <2026-07-20T21:17:00+07:00> & <2026-11-20T17:30:00+07:00>
     * - Thêm x-correlation-id và X-Turnstile-Token cho Onboarding (UAT Bug 5).
     */
    origin: securityConfig.ALLOWED_ORIGINS,
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
    allowedHeaders: [
      'Content-Type',
      'Authorization',
      'x-tenant-slug',
      'X-Correlation-Id',
      'x-correlation-id',
      'X-Turnstile-Token',
      'X-Requested-With',
    ],
    exposedHeaders: ['X-Correlation-Id', 'x-correlation-id'],
  })
);

// [21.10.0-UAT-BUG5-CORS-FIX] Phản hồi 204 ngay lập tức cho preflight OPTIONS
app.options('*', cors());

app.use(express.json());

// Public tenant resolve (pre-auth). Không phải authorization.
// Request đã login: verifyToken ghi đè ALS từ JWT (S0.1).
app.use(async (req, res, next) => {
  const slug = req.headers['x-tenant-slug'] || req.query.slug;

  if (!slug) return next();

  try {
    const tenant = await basePrisma.tenants.findUnique({
      where: { slug },
    });

        if (!tenant) {
          // [21.7.0-W2] PR-W2-3: Đưa vào Global Handler → dual-contract CED
          const err = new Error('Không tìm thấy dòng họ này.');
          err.code = 'TENANT_NOT_FOUND';
          err.statusCode = 404;
          err.isOperational = true;
          err.correlationId = req.correlationId;
          return next(err);
        }

    tenantContext.run({ tenantId: tenant.id }, () => next());
  } catch (err) {
    next(err);
  }
});

// ROUTES
app.get('/', (req, res) =>
  res.json({
    status: 'Online',
    app: securityConfig.APP_NAME,
    version: '21.10.0-UAT-BUG5-CORS-FIX',
    environment: securityConfig.NODE_ENV,
  })
);

// [AMEND-RP-OP-2026-02 V1.5.0] Public search endpoints cho Guest Claim (không yêu cầu JWT)
app.use('/api/public', publicSearchRoutes);

if (typeof authRoutes === 'function') {
  app.use('/api/auth', authRoutes);
}

// Rate Limiting
app.use('/api/auth/login', loginRateLimiter);
app.use('/api/auth/register', loginRateLimiter);

// Các route khác giữ nguyên
app.use('/api/members', memberRoutes);
app.use('/api/branches', branchRoutes);
app.use('/api/mfo', mfoRoutes);
app.use('/api/addresses', addressRoutes);
app.use('/api/worships', worshipRoutes);
app.use('/api/tenants', tenantRoutes);
app.use('/api/achievements', achievementRoutes);
app.use('/api/assets', assetRoutes);
app.use('/api/cemeteries', cemeteryRoutes);
app.use('/api/graves', graveRoutes);
app.use('/api/events', eventRoutes);
app.use('/api/funds', fundRoutes);
app.use('/api/fund-transactions', fundTransactionRoutes);
app.use('/api/media', mediaRoutes);
app.use('/api/suggestions', suggestionRoutes);
app.use('/api/auth-logs', authLogRoutes);
app.use('/api/notifications', notificationRoutes);

// [21.5.2] Onboarding — EGAL-25.x OPD v1.1.0 (Phase 1–3)
// Prefix nhất quán với các module hiện tại (/api/members, /api/branches, ...)
app.use('/api/onboarding', onboardingRoutes);
app.use('/api/membership', membershipRoutes);
app.use('/api/me', profileRoutes);

// ─────────────────────────────────────────────────────────────
// [21.6.0-W1] 404 Catcher → chuyển thành AppError để đi vào Global Handler
// ─────────────────────────────────────────────────────────────
app.use((req, res, next) => {
  const err = new Error(`Cannot ${req.method} ${req.originalUrl}`);
  err.code = 'NOT_FOUND';
  err.statusCode = 404;
  err.isOperational = true;
  err.correlationId = req.correlationId;
  next(err);
});


// ─────────────────────────────────────────────────────────────
// [21.6.0-W1] CED Global Error Handler (legacy: true — dual-contract)
// Thay thế handler 500 mù trước đây.
// ─────────────────────────────────────────────────────────────
app.use(createGlobalErrorHandler({ legacy: true }));

// [UAT-IMP6] Quét tự động vòng đời Sandbox 30 ngày + 30 ngày đệm TAM_NGUNG
if (process.env.NODE_ENV !== 'test') {
  const sandboxLifecycleWorker = require('./jobs/sandboxLifecycle.worker');
  const SANDBOX_SWEEP_INTERVAL_MS = 6 * 60 * 60 * 1000; // 6 giờ / lần
  const startupTimer = setTimeout(() => {
    sandboxLifecycleWorker.runOnce().catch((err) => {
      console.error('[sandboxLifecycleWorker][startup]', err.message || err);
    });
  }, 30 * 1000);
  if (typeof startupTimer.unref === 'function') startupTimer.unref();

  const periodicTimer = setInterval(() => {
    sandboxLifecycleWorker.runOnce().catch((err) => {
      console.error('[sandboxLifecycleWorker][interval]', err.message || err);
    });
  }, SANDBOX_SWEEP_INTERVAL_MS);
  if (typeof periodicTimer.unref === 'function') periodicTimer.unref();
}

module.exports = app;
